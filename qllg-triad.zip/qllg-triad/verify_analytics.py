"""Numerical checks of the analytic statements about the quantum triad.

Each check prints PASS/FAIL.  Runtime ~2 min (dominated by the constrained minimizations, which test
that the analytic minimizers are global).  Units hbar = omega = 1, eps = sqrt(3).
"""
import numpy as np
from scipy.linalg import expm
from scipy.optimize import minimize

from triad_qllg import (EPS, H, J, J2, SIG, KET, P_MINUS, CHI, comm, charge, expval, raising,
                        closure_state, rank2_minimizer, Emin_pure, Emin_rank2_zero_charge,
                        multipliers, pure_multipliers_closed_form, velocity)

rng = np.random.default_rng(0)
RESULTS = []


def check(name, ok, detail=""):
    RESULTS.append(ok)
    print(f"[{'PASS' if ok else 'FAIL'}] {name}" + (f"  ({detail})" if detail else ""))


def constrained_min(spectrum, q, restarts=30):
    """SLSQP minimum of <H> over states with the given spectrum and |<J>| = q (q = 0: <J> = 0)."""
    r = len(spectrum)

    def build(x):
        A = (x[:8 * r] + 1j * x[8 * r:]).reshape(8, r)
        Q, _ = np.linalg.qr(A)
        W = Q @ np.diag(np.sqrt(spectrum))
        return W @ W.conj().T

    f = lambda x: expval(build(x), H)
    c = (lambda x: charge(build(x))) if q == 0 else (lambda x: np.linalg.norm(charge(build(x))) - q)
    best = None
    for _ in range(restarts):
        s = minimize(f, rng.normal(size=16 * r), method="SLSQP", constraints=[{"type": "eq", "fun": c}],
                     options={"ftol": 1e-13, "maxiter": 2000})
        if np.linalg.norm(c(s.x)) < 1e-8 and (best is None or s.fun < best[0]):
            best = (s.fun, build(s.x))
    return best


# 1. spectrum and symmetries ------------------------------------------------------------------
ev = np.linalg.eigvalsh(H)
check("spectrum of H is {-eps x2, 0 x4, +eps x2}", np.allclose(ev, [-EPS] * 2 + [0] * 4 + [EPS] * 2, atol=1e-12))
check("[H, J_a] = 0", max(np.abs(comm(H, Ja)).max() for Ja in J) < 1e-12)
check("[J_a, J_b] = i eps_abc J_c", all(np.allclose(comm(J[a], J[b]), 1j * sum(
    (1 if (a, b, c) in [(0, 1, 2), (1, 2, 0), (2, 0, 1)] else -1 if (a, b, c) in [(1, 0, 2), (2, 1, 0), (0, 2, 1)] else 0) * J[c]
    for c in range(3))) for a in range(3) for b in range(3)))
Theta = SIG[0][1] @ SIG[1][1] @ SIG[2][1]            # time reversal: Theta K, Theta = prod_i (i sigma_y) up to phase
check("H odd under time reversal", np.allclose(Theta @ H.conj() @ Theta.conj().T, -H))
P23 = np.kron(np.eye(2), np.array([[1, 0, 0, 0], [0, 0, 1, 0], [0, 1, 0, 0], [0, 0, 0, 1]], complex))
check("H odd under transposition of sites 2,3", np.allclose(P23 @ H @ P23, -H))
C3 = np.zeros((8, 8), complex)                        # cyclic permutation of sites 1->2->3->1
for s in range(8):
    b = [(s >> 2) & 1, (s >> 1) & 1, s & 1]
    t = (b[2] << 2) | (b[0] << 1) | b[1]
    C3[t, s] = 1
check("H invariant under cyclic permutation", np.allclose(C3 @ H @ C3.conj().T, H))
check("chi = +-2 sqrt3 on the doublets, 0 on the quadruplet",
      np.allclose(np.linalg.eigvalsh(CHI), [-2 * EPS] * 2 + [0] * 4 + [2 * EPS] * 2))

# 2. pure minimizer at <J> = 0 -------------------------------------------------------------
psi = closure_state(phi=0.7)
rho = np.outer(psi, psi.conj())
check("closure state: <J> = 0, E = -3 eps/4", np.linalg.norm(charge(rho)) < 1e-12 and abs(expval(rho, H) + 0.75 * EPS) < 1e-12)
K = H + 0.5 * EPS * J[2]
check("closure state: [H + (eps/2) J_n, rho] = 0", np.abs(comm(K, rho)).max() < 1e-12)
check("closure state: <sigma_i> = 0 for all i", max(abs(expval(rho, SIG[i][a])) for i in range(3) for a in range(3)) < 1e-12)
c = np.trace(rho @ raising(0) @ raising(1))
check("closure state: |<s1+ s2+>| = 1/4", abs(abs(c) - 0.25) < 1e-12)
U = expm(-1j * H * 0.3)
c2 = np.trace(U @ rho @ U.conj().T @ raising(0) @ raising(1))
check("closure state: correlation rotates at sqrt3 omega", abs(np.angle(c2 / c) + EPS * 0.3) < 1e-10)
best = constrained_min([1.0], 0.0)
check("closure state is the global pure minimum at <J> = 0", abs(best[0] + 0.75 * EPS) < 1e-6, f"SLSQP {best[0]/EPS:+.7f} eps")

# 3. rank-two minimizers at <J> = 0 ------------------------------------------------------------
for p in (0.6, 0.75, 0.9):
    rho = rank2_minimizer(p, phi=0.4)
    ok = (np.allclose(np.sort(np.linalg.eigvalsh(rho))[-2:], [1 - p, p]) and np.linalg.norm(charge(rho)) < 1e-12
          and abs(expval(rho, H) - Emin_rank2_zero_charge(p)) < 1e-12 and np.abs(comm(K, rho)).max() < 1e-12
          and max(abs(expval(rho, SIG[i][a])) for i in range(3) for a in range(3)) < 1e-12)
    check(f"rank-two minimizer p={p}: spectrum, <J>=0, E=-(5-2p)eps/4, eigen-equation, <sigma_i>=0", ok)
    best = constrained_min([p, 1 - p], 0.0)
    check(f"rank-two minimizer p={p} is the global minimum", abs(best[0] - Emin_rank2_zero_charge(p)) < 1e-6,
          f"SLSQP {best[0]/EPS:+.7f} eps vs {Emin_rank2_zero_charge(p)/EPS:+.7f}")
rho_half = 0.5 * P_MINUS
check("p=1/2: P_-/2 has E = -eps, <J> = 0 and commutes with H and J_a",
      abs(expval(rho_half, H) + EPS) < 1e-12 and np.linalg.norm(charge(rho_half)) < 1e-12
      and max(np.abs(comm(A, rho_half)).max() for A in [H] + J) < 1e-12)
best = constrained_min([0.5, 0.5], 0.1)
check("spectrum (1/2,1/2) at |<J>| = 0.1: E_min = -eps (1 - q/2)", abs(best[0] + EPS * (1 - 0.05)) < 1e-6,
      f"SLSQP {best[0]/EPS:+.7f} eps")

# 4. nonzero charge, pure states --------------------------------------------------------------
for q in (0.25, 0.75, 1.25):
    best = constrained_min([1.0], q)
    check(f"pure E_min(q={q}) = {float(Emin_pure(q))/EPS:+.5f} eps", abs(best[0] - float(Emin_pure(q))) < 1e-6,
          f"SLSQP {best[0]/EPS:+.7f} eps")
    if q > 0.5:                                       # branch 2: single spins precess
        rho = best[1]
        n = charge(rho) / q
        sig = np.array([[expval(rho, SIG[i][a]) for a in range(3)] for i in range(3)])
        long = sig @ n
        trans = np.linalg.norm(sig - np.outer(long, n), axis=1)
        pb = 1.5 - q
        check(f"  branch 2, q={q}: longitudinal 2q/3, transverse 2 sqrt(p(1-p))/sqrt3",
              np.allclose(long, 2 * q / 3, atol=1e-6) and np.allclose(trans, 2 * np.sqrt(pb * (1 - pb)) / np.sqrt(3), atol=1e-6))

# 5. multipliers: closed form for pure states vs general linear system ------------------------
for kappa in (0.2, 0.5, 2.0):
    v = rng.normal(size=8) + 1j * rng.normal(size=8); v /= np.linalg.norm(v)
    lam_sys, _ = multipliers(np.outer(v, v.conj()), kappa)
    lam_cf = pure_multipliers_closed_form(v, kappa)
    X, rd, _ = velocity(np.outer(v, v.conj()), kappa, lam_sys)
    check(f"pure-state multiplier closed form (kappa={kappa}); charge conserved",
          np.allclose(lam_sys, lam_cf, atol=1e-10) and max(abs(np.real(np.trace(rd @ Ja))) for Ja in J) < 1e-12)

# 6. relative equilibria are fixed points of the covariant flow ------------------------------
for name, rho in (("closure", np.outer(closure_state(), closure_state().conj())), ("rank-two p=0.75", rank2_minimizer(0.75))):
    X, rd, lam = velocity(rho, 0.5)
    check(f"{name}: D_t rho = 0 with lam = (eps/2) n, rho_dot != 0",
          np.linalg.norm(X) < 1e-12 and np.allclose(lam, [0, 0, 0.5 * EPS], atol=1e-10) and np.linalg.norm(rd) > 0.1,
          f"||rho_dot|| = {np.linalg.norm(rd):.4f}")

print(f"\n{sum(RESULTS)}/{len(RESULTS)} checks passed")
