"""Covariant qLLG relaxation of the quantum triad at <J> = 0 from random initial states.

Three families, three runs each (seeded, hence reproducible):
    pure states                         -> moving attractor (closure_state)
    rank two, spectrum (3/4, 1/4)       -> moving attractor (rank2_minimizer)
    rank two, spectrum (1/2, 1/2)       -> static attractor, P_-/2
Writes flow_runs.pkl (input of make_fig_flow.py) and prints a summary table.  Runtime ~1 min.
"""
import pickle
import time

import numpy as np

from triad_qllg import EPS, random_amplitude, run

KAPPA, T, NT = 0.5, 60.0, 1201
FAMILIES = {"pure": [1.0], "mixed": [0.75, 0.25], "half": [0.5, 0.5]}
TARGET = {"pure": -0.75, "mixed": -0.875, "half": -1.0}       # E_min / eps

if __name__ == "__main__":
    rng = np.random.default_rng(20261024)
    data = {}
    print(f"{'family':6s} run  E(0)/eps   E(T)/eps     |lam(T)|/eps  max|<J>|  spec drift  ||D_t rho||(T)  ||rho_dot||(T)  time")
    for name, spectrum in FAMILIES.items():
        data[name] = []
        for i in range(3):
            t0 = time.time()
            o = run(random_amplitude(spectrum, rng), kappa=KAPPA, T=T, n=NT)
            data[name].append(o)
            print(f"{name:6s} {i:3d}  {o['E'][0]/EPS:+.3f}   {o['E'][-1]/EPS:+.8f}  {np.linalg.norm(o['lam'][-1])/EPS:.6f}      "
                  f"{np.linalg.norm(o['j'], axis=1).max():.0e}    {np.abs(o['spec'] - o['spec'][0]).max():.0e}       "
                  f"{o['normX'][-1]:.0e}         {o['normRhoDot'][-1]:.1e}       {time.time() - t0:.0f} s")
        print(f"{'':6s}      target E_min/eps = {TARGET[name]:+.3f}")
    pickle.dump(data, open("flow_runs.pkl", "wb"))
    print("saved flow_runs.pkl")
