"""Figure: covariant qLLG relaxation of the quantum triad (reads flow_runs.pkl from run_flow_data.py).

(a) energy; (b) ||D_t rho|| (thick) and ||rho_dot|| (thin); (c) two-spin correlation on the attractor.
Blue solid: pure; orange dashed: rank two (3/4, 1/4); black dotted: rank two (1/2, 1/2).
Output: fig_flow.pdf (3.4 x 2.1 in) and fig_flow.png.
"""
import pickle

import matplotlib
import numpy as np

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec

from triad_qllg import EPS, SIG, raising

data = pickle.load(open("flow_runs.pkl", "rb"))
BLUE, ORANGE, INK, GREY = "#2a78d6", "#eb6834", "#0b0b0b", "#52514e"
STYLE = {"pure": dict(color=BLUE, ls="-"), "mixed": dict(color=ORANGE, ls=(0, (4, 1.6))),
         "half": dict(color=INK, ls=(0, (1, 1.3)))}
plt.rcParams.update({
    "font.family": "serif", "font.serif": ["cmr10", "DejaVu Serif"], "mathtext.fontset": "cm",
    "axes.formatter.use_mathtext": True, "font.size": 7.5, "axes.labelsize": 7.5,
    "xtick.labelsize": 6.5, "ytick.labelsize": 6.5, "axes.linewidth": 0.5,
    "xtick.major.width": 0.5, "ytick.major.width": 0.5, "xtick.minor.width": 0.4,
    "ytick.minor.width": 0.4, "xtick.major.size": 2.5, "ytick.major.size": 2.5,
    "xtick.minor.size": 1.5, "ytick.minor.size": 1.5, "xtick.direction": "in",
    "ytick.direction": "in", "axes.unicode_minus": True, "pdf.fonttype": 42,
})
W, Hfig = 3.4, 2.1
fig = plt.figure(figsize=(W, Hfig))
gs = GridSpec(2, 2, figure=fig, left=0.125, right=0.985, bottom=0.165, top=0.975, wspace=0.62, hspace=0.12)
axA = fig.add_subplot(gs[0, 0])
axB = fig.add_subplot(gs[1, 0], sharex=axA)
axC = fig.add_subplot(gs[:, 1])
lw = 1.0

# (a) energy
for y in (-0.75, -0.875, -1.0):
    axA.axhline(y, color=GREY, lw=0.4, alpha=0.7, zorder=0)
for key in ("pure", "mixed", "half"):
    for o in data[key]:
        axA.plot(o["t"], o["E"] / EPS, lw=lw, **STYLE[key])
axA.set_xlim(0, 60); axA.set_ylim(-1.32, 0.36)
axA.set_yticks([-1, -0.5, 0]); axA.set_yticklabels([r"$-1$", r"$-0.5$", r"$0$"])
axA.set_ylabel(r"$\langle H\rangle/\varepsilon$", labelpad=1)
axA.tick_params(labelbottom=False)
axA.text(58, -1.05, r"$(\frac{1}{2},\frac{1}{2})$", color=INK, ha="right", va="top", fontsize=6.5)

# (b) norms
for key in ("pure", "mixed", "half"):
    for o in data[key]:
        axB.semilogy(o["t"], o["normRhoDot"], lw=0.7, alpha=0.9, **STYLE[key])
        axB.semilogy(o["t"], o["normX"], lw=lw, **STYLE[key])
axB.set_ylim(1e-12, 3e1); axB.set_yticks([1e-12, 1e-8, 1e-4, 1e0]); axB.minorticks_off()
axB.set_xticks([0, 20, 40, 60])
axB.set_xlabel(r"$\omega t$", labelpad=1)
axB.set_ylabel(r"$\Vert\cdot\Vert/\omega$", labelpad=1)
axB.text(58, 10**-1.4, r"$\Vert\dot\rho\Vert$", ha="right", va="center", fontsize=6.5)
axB.text(43, 10**-10.4, r"$\Vert\mathcal{D}_t\rho\Vert$", ha="left", va="center", fontsize=6.5)


# (c) two-spin correlation on the attractor, in the frame selected by the flow
def corr(o, t0, t1):
    n = o["lam"][-1] / np.linalg.norm(o["lam"][-1])
    op = raising(0, n) @ raising(1, n)
    sel = (o["t"] >= t0) & (o["t"] <= t1)
    c = np.array([np.trace(Wk @ Wk.conj().T @ op) for Wk in o["W"][sel]])
    s1 = np.array([max(abs(np.trace(Wk @ Wk.conj().T @ SIG[0][k])) for k in range(3)) for Wk in o["W"][sel]])
    return o["t"][sel], c, s1


t0, t1 = 50.0, 60.0
for key in ("pure", "mixed"):
    tt, c, s1 = corr(data[key][0], t0, t1)
    axC.plot(tt, c.real, lw=lw, **STYLE[key])
    axC.plot(tt, s1, lw=0.7, color=STYLE[key]["color"], ls=STYLE[key]["ls"])
    print(f"{key}: |<s1+ s2+>| = {abs(c).mean():.4f}, max|<sigma_1>| = {s1.max():.0e}")
tt, c, _ = corr(data["pure"][0], t0, t1)
cr = c.real
pk = [i for i in range(1, len(cr) - 1) if cr[i] > cr[i - 1] and cr[i] >= cr[i + 1] and tt[i] > 52]
ta, tb = tt[pk[0]], tt[pk[1]]
axC.annotate("", xy=(ta, 0.285), xytext=(tb, 0.285), arrowprops=dict(arrowstyle="<->", lw=0.5, color=INK, shrinkA=0, shrinkB=0))
axC.text((ta + tb) / 2, 0.29, r"$T$", ha="center", va="bottom", fontsize=6.5)
axC.text(59.6, 0.0, r"$\langle\boldsymbol{\sigma}_i\rangle$", ha="right", va="center", fontsize=6.5, color=INK,
         bbox=dict(boxstyle="square,pad=0.1", fc="white", ec="none"))
axC.text(52.6, 0.335, "pure", color=BLUE, ha="left", va="top", fontsize=6.5)
axC.text(59.85, 0.225, r"$(\frac{3}{4},\frac{1}{4})$", color=ORANGE, ha="right", va="center", fontsize=6.5)
axC.set_xlim(t0, t1); axC.set_ylim(-0.3, 0.36)
axC.set_xticks([50, 55, 60]); axC.set_yticks([-0.25, 0, 0.25]); axC.set_yticklabels([r"$-0.25$", r"$0$", r"$0.25$"])
axC.set_xlabel(r"$\omega t$", labelpad=1)
axC.set_ylabel(r"$\mathrm{Re}\,\langle\sigma_1^+\sigma_2^+\rangle$", labelpad=0.5)

axA.text(0.035, 0.94, "(a)", transform=axA.transAxes, ha="left", va="top", fontsize=7.5)
axB.text(0.035, 0.06, "(b)", transform=axB.transAxes, ha="left", va="bottom", fontsize=7.5)
axC.text(0.035, 0.955, "(c)", transform=axC.transAxes, ha="left", va="top", fontsize=7.5)
for ax in (axA, axB, axC):
    ax.tick_params(which="both", top=True, right=True)

# layout check: no text label may touch a data line (bounding boxes padded by 1 pt);
# <sigma_i> is an inline label on its own (zero) line, drawn on a white box, and is exempt
fig.canvas.draw()
rend = fig.canvas.get_renderer()
clash = []
for ax in (axA, axB, axC):
    pts = np.vstack([ax.transData.transform(np.column_stack(l.get_data())) for l in ax.get_lines()])
    for txt in ax.texts:
        if not txt.get_text() or "sigma}_i" in txt.get_text():
            continue
        bb = txt.get_window_extent(rend).expanded(1.0, 1.0).padded(fig.dpi / 72)
        if np.any((pts[:, 0] > bb.x0) & (pts[:, 0] < bb.x1) & (pts[:, 1] > bb.y0) & (pts[:, 1] < bb.y1)):
            clash.append(txt.get_text())
print("labels touching data lines:", clash if clash else "none")
fig.savefig("fig_flow.pdf")
fig.savefig("fig_flow.png", dpi=600)
print("peak spacing / T =", (tb - ta) / (2 * np.pi / np.sqrt(3)))
