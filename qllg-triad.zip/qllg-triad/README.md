# qllg-triad

Covariant quantum Landau–Lifshitz–Gilbert (qLLG) relaxation of a chiral spin triad.

The code integrates the covariant qLLG flow for three spins-½ coupled through their scalar chirality,
with the Lagrange multipliers of the conserved total spin determined dynamically by charge
conservation, and verifies numerically that the flow converges to the constrained energy minima
derived analytically — moving ones (quantum time crystals) or static ones, depending on the
spectrum of the density matrix.

## Model and equations

Units ħ = ω = 1, ε = √3.

* Hamiltonian and charges: `H = ½ σ₁·(σ₂×σ₃)`, `J_a = ½ Σᵢ σᵢᵃ`, with `[H, J_a] = 0`.
* Covariant qLLG flow:
  `i ρ̇ = [H + κ 𝒟ₜρ, ρ]`, `i 𝒟ₜρ = [H + λ·J + κ 𝒟ₜρ, ρ]`.
  In the eigenbasis `ρ = Σ pₖ|k⟩⟨k|` the second equation is solved by
  `(𝒟ₜρ)ₖₗ = (H + λ·J)ₖₗ (pₗ − pₖ) / [i − κ(pₗ − pₖ)]`, which is affine in λ.
* Multipliers: `d⟨J_a⟩/dt = iκ Tr(𝒟ₜρ [J_a, ρ]) = 0` is a real 3×3 linear system for λ(t), solved at
  every stage of the integration. For pure states it reduces to
  `2C λ + κ λ×⟨J⟩ = −2(⟨HJ⟩ − ⟨H⟩⟨J⟩)`, `C_ab = ½⟨{J_a,J_b}⟩ − ⟨J_a⟩⟨J_b⟩`.
* State representation: Uhlmann amplitudes `W` (8×r), `ρ = WW†`, `W†W = P` (prescribed spectrum).
  In the gauge 𝒜 = 0, E = 0 the amplitude equation `i Ẇ = (H + κ 𝒟ₜρ) W` has a Hermitian
  generator, so the spectrum of ρ is conserved by construction.
* Integration: explicit eighth-order Dormand–Prince Runge–Kutta (`scipy` DOP853),
  relative tolerance 1e-10, κ = 0.5.
* Initial states: Gaussian random amplitudes, orthonormalized and scaled by `P^{1/2}`, then corrected
  by least squares to ⟨J⟩ = 0. No information about the minimizers enters.

## Files

| file | purpose |
|---|---|
| `triad_qllg.py` | operators, closed-form covariant velocity, multiplier solver, amplitude integrator, analytic minimizers |
| `run_flow_data.py` | relaxation from random initial states: pure, rank two (¾,¼), rank two (½,½); three runs each → `flow_runs.pkl` |
| `make_fig_flow.py` | the figure (`fig_flow.pdf`, 3.4 × 2.1 in) from `flow_runs.pkl` |
| `verify_analytics.py` | 31 numerical checks of the analytic results (spectrum, symmetries, minimizers, global optimality, multipliers) |
| `fig_flow.pdf` | the relaxation figure |

## Usage

```bash
pip install -r requirements.txt
python verify_analytics.py     # ~2 min: prints PASS/FAIL for each analytic statement
python run_flow_data.py        # ~1 min: runs the flow, writes flow_runs.pkl and a summary table
python make_fig_flow.py        # writes fig_flow.pdf and fig_flow.png
```

Expected summary (all nine runs): energies converge to −¾ε, −⅞ε and −ε to 1e-7; on the moving
attractors |λ| → ε/2 to 1e-8; charge and spectrum constant to 1e-10; ‖𝒟ₜρ‖ decays exponentially at
rates ≈ 0.8ω (pure), 0.12ω (¾,¼) and 0.35ω (½,½), while ‖ρ̇‖ tends to 1.06ω, 0.68ω and 0.

Runs are seeded (`numpy.random.default_rng(20261024)`), so results are reproducible.

## A note on the (½,½) runs

For equal eigenvalues the static minimum `P₋/2` exists only at *exactly* zero mean spin. The initial
least-squares correction leaves a residual charge q ≈ 1e-12, and the flow correctly finds the
minimizer at that charge, which moves with ‖ρ̇‖ = ε√(q/2) ≈ 1e-6 and λ = (ε/2)n. This is the floor of
the dotted ‖ρ̇‖ curves in panel (b) of the figure; it is physics, not a numerical artifact.

## License

MIT, see `LICENSE`.
