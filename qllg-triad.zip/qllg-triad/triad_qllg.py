"""Covariant quantum Landau-Lifshitz-Gilbert (qLLG) relaxation of the quantum triad.

Model (units hbar = omega = 1):
    H   = (1/2) sigma_1 . (sigma_2 x sigma_3) = (1/2) chi
    J_a = (1/2) sum_i sigma_i^a                       [H, J_a] = 0
    eps = sqrt(3): spectrum of H is {-eps (doublet), 0 (quadruplet), +eps (doublet)}

Covariant qLLG equation for the density matrix rho:
    i rho_dot      = [H + kappa X, rho],          X = D_t rho,
    i X            = [H + lam.J + kappa X, rho].
In the eigenbasis rho = sum_k p_k |k><k| the second equation is solved by
    X_kl = (H + lam.J)_kl (p_l - p_k) / (i - kappa (p_l - p_k)),
which is affine in lam.  Charge conservation, d<J_a>/dt = i kappa Tr(X [J_a, rho]) = 0,
is then a real 3x3 linear system for the multipliers lam(t).

The state is carried by Uhlmann amplitudes W (8 x r), rho = W W^dagger, W^dagger W = P
(the prescribed spectrum).  In the gauge A = 0, E = 0 the amplitude equation reads
    i W_dot = (H + kappa X) W,
whose Hermitian generator conserves W^dagger W, hence the spectrum of rho.
"""
import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import least_squares

EPS = np.sqrt(3.0)

# ----------------------------------------------------------------------------- operators
_sx = np.array([[0, 1], [1, 0]], complex)
_sy = np.array([[0, -1j], [1j, 0]], complex)
_sz = np.array([[1, 0], [0, -1]], complex)
_I2 = np.eye(2, dtype=complex)


def _site(op, i):
    mats = [_I2, _I2, _I2]
    mats[i] = op
    return np.kron(np.kron(mats[0], mats[1]), mats[2])


SIG = [[_site(s, i) for s in (_sx, _sy, _sz)] for i in range(3)]   # SIG[i][a]: Pauli a on site i
LEVI = np.zeros((3, 3, 3))
for a, b, c in [(0, 1, 2), (1, 2, 0), (2, 0, 1)]:
    LEVI[a, b, c], LEVI[b, a, c] = 1.0, -1.0
CHI = sum(LEVI[a, b, c] * SIG[0][a] @ SIG[1][b] @ SIG[2][c]
          for a in range(3) for b in range(3) for c in range(3) if LEVI[a, b, c])
H = 0.5 * CHI
J = [0.5 * (SIG[0][a] + SIG[1][a] + SIG[2][a]) for a in range(3)]
J2 = sum(Ja @ Ja for Ja in J)


def comm(A, B):
    return A @ B - B @ A


def expval(rho, A):
    return float(np.real(np.trace(rho @ A)))


def charge(rho):
    return np.array([expval(rho, Ja) for Ja in J])


def raising(i, n=(0.0, 0.0, 1.0)):
    """sigma_i^+ = (sigma_i.e1 + i sigma_i.e2)/2 for a right-handed frame (e1, e2, n)."""
    n = np.asarray(n, float) / np.linalg.norm(n)
    ref = np.array([1.0, 0.0, 0.0]) if abs(n[0]) < 0.9 else np.array([0.0, 1.0, 0.0])
    e1 = np.cross(n, ref); e1 /= np.linalg.norm(e1); e2 = np.cross(n, e1)
    return sum((e1[k] + 1j * e2[k]) * SIG[i][k] for k in range(3)) / 2


def joint_eigenstate(energy, m, j):
    """Joint eigenvector of H, J_z, J^2 with eigenvalues energy, m, j(j+1); phase fixed."""
    A = sum(M.conj().T @ M for M in (H - energy * np.eye(8), J[2] - m * np.eye(8),
                                      J2 - j * (j + 1) * np.eye(8)))
    w, V = np.linalg.eigh(A)
    assert w[0] < 1e-10, "no such joint eigenstate"
    v = V[:, 0]
    k = np.argmax(abs(v))
    return v * abs(v[k]) / v[k]


# ground doublet |-,m>, excited doublet |+,m>, quadruplet |3/2,m>, quantized along z
KET = {("-", 0.5): joint_eigenstate(-EPS, 0.5, 0.5), ("-", -0.5): joint_eigenstate(-EPS, -0.5, 0.5),
       ("+", 0.5): joint_eigenstate(EPS, 0.5, 0.5), ("+", -0.5): joint_eigenstate(EPS, -0.5, 0.5)}
for _m in (1.5, 0.5, -0.5, -1.5):
    KET[("3/2", _m)] = joint_eigenstate(0.0, _m, 1.5)
P_MINUS = sum(np.outer(KET[("-", m)], KET[("-", m)].conj()) for m in (0.5, -0.5))   # ground-doublet projector


# ------------------------------------------------------------------- covariant qLLG flow
def covariant_velocity(rho, K, kappa):
    """Solve i X = [K + kappa X, rho] for Hermitian X (closed form in the eigenbasis of rho)."""
    p, U = np.linalg.eigh(rho)
    Kt = U.conj().T @ K @ U
    dp = p[None, :] - p[:, None]                      # dp_kl = p_l - p_k
    Xt = Kt * dp / (1j - kappa * dp)
    return U @ Xt @ U.conj().T


def multipliers(rho, kappa, rcond=1e-10):
    """Multipliers lam from charge conservation Im Tr(X(lam) [J_a, rho]) = 0 (X is affine in lam).

    Returns (lam, M): the least-squares solution and the 3x3 system matrix (rank-deficient when
    the symmetry directions [J_a, rho] are linearly dependent, e.g. at rotationally invariant rho)."""
    X0 = covariant_velocity(rho, H, kappa)
    Xb = [covariant_velocity(rho, J[b], kappa) for b in range(3)]
    cJ = [comm(J[a], rho) for a in range(3)]
    M = np.array([[np.imag(np.trace(Xb[b] @ cJ[a])) for b in range(3)] for a in range(3)])
    r = np.array([-np.imag(np.trace(X0 @ cJ[a])) for a in range(3)])
    lam = np.linalg.lstsq(M, r, rcond=rcond)[0]
    return lam, M


def velocity(rho, kappa, lam=None):
    """Return (D_t rho, rho_dot, lam) at the state rho."""
    if lam is None:
        lam, _ = multipliers(rho, kappa)
    K = H + sum(lam[a] * J[a] for a in range(3))
    X = covariant_velocity(rho, K, kappa)
    rho_dot = -1j * comm(H + kappa * X, rho)
    return X, rho_dot, lam


def pure_multipliers_closed_form(psi, kappa):
    """Pure states: 2 C lam + kappa lam x <J> = -2 (<H J> - <H><J>),  C_ab = <{J_a,J_b}>/2 - <J_a><J_b>."""
    rho = np.outer(psi, psi.conj())
    j = charge(rho)
    C = np.array([[expval(rho, (J[a] @ J[b] + J[b] @ J[a]) / 2) - j[a] * j[b] for b in range(3)] for a in range(3)])
    cH = np.array([expval(rho, (H @ J[a] + J[a] @ H) / 2) - expval(rho, H) * j[a] for a in range(3)])
    E = np.einsum("abc,c->ab", LEVI, j)
    return np.linalg.solve(2 * C + kappa * E, -2 * cH)


# --------------------------------------------------------------------- initial amplitudes
def random_amplitude(spectrum, rng, charge_norm=0.0):
    """Random W (8 x r) with W^dagger W = diag(spectrum) and |<J>| = charge_norm (direction free).

    A Gaussian random matrix is orthonormalized (QR) and scaled by P^{1/2}; a least-squares
    correction of its 16 r real parameters then imposes the charge, preserving W^dagger W."""
    spectrum = np.asarray(spectrum, float)
    r = len(spectrum)

    def build(x):
        A = (x[:8 * r] + 1j * x[8 * r:]).reshape(8, r)
        Q, _ = np.linalg.qr(A)
        return Q @ np.diag(np.sqrt(spectrum))

    def resid(x):
        W = build(x)
        j = charge(W @ W.conj().T)
        return list(j) if charge_norm == 0.0 else [np.linalg.norm(j) - charge_norm]

    x = least_squares(resid, rng.normal(size=16 * r), xtol=1e-15, ftol=1e-15, gtol=1e-15).x
    return build(x)


# ------------------------------------------------------------------------------ integration
def run(W0, kappa=0.5, T=60.0, n=1201, rtol=1e-10, atol=1e-13):
    """Integrate i W_dot = (H + kappa D_t rho) W with the multipliers solved at every stage.

    Returns a dict with t, E, lam, j (= <J>), spec (eigenvalues of W^dagger W), normX (= ||D_t rho||),
    normRhoDot (= ||rho_dot||), and W (the amplitudes at the output times)."""
    r = W0.shape[1]

    def rhs(t, y):
        W = (y[:8 * r] + 1j * y[8 * r:]).reshape(8, r)
        X, _, _ = velocity(W @ W.conj().T, kappa)
        dW = -1j * (H + kappa * X) @ W
        return np.concatenate([dW.real.ravel(), dW.imag.ravel()])

    t = np.linspace(0.0, T, n)
    y0 = np.concatenate([W0.real.ravel(), W0.imag.ravel()])
    sol = solve_ivp(rhs, (0.0, T), y0, t_eval=t, method="DOP853", rtol=rtol, atol=atol)
    out = {k: [] for k in ("E", "lam", "j", "spec", "normX", "normRhoDot")}
    Ws = []
    for k in range(sol.y.shape[1]):
        W = (sol.y[:8 * r, k] + 1j * sol.y[8 * r:, k]).reshape(8, r)
        rho = W @ W.conj().T
        X, rd, lam = velocity(rho, kappa)
        out["E"].append(expval(rho, H)); out["lam"].append(lam); out["j"].append(charge(rho))
        out["spec"].append(np.sort(np.linalg.eigvalsh(W.conj().T @ W)))
        out["normX"].append(np.linalg.norm(X)); out["normRhoDot"].append(np.linalg.norm(rd))
        Ws.append(W)
    out = {k: np.array(v) for k, v in out.items()}
    out["t"] = t
    out["W"] = np.array(Ws)
    return out


# ---------------------------------------------------------------------- analytic results
def Emin_pure(q):
    """Constrained minimum energy of pure states at |<J>| = q (two branches, kink at q = 1/2)."""
    q = np.asarray(q, float)
    return np.where(q <= 0.5, -0.5 * EPS * (1.5 + q), -EPS * (1.5 - q))


def Emin_rank2_zero_charge(p):
    """Rank-two states with spectrum (p, 1-p), 1/2 <= p <= 1, at <J> = 0:  -(5 - 2p) eps / 4."""
    return -0.25 * (5.0 - 2.0 * np.asarray(p, float)) * EPS


def closure_state(phi=0.0):
    """Pure minimizer at <J> = 0 quantized along z."""
    return np.sqrt(3) / 2 * KET[("-", 0.5)] + 0.5 * np.exp(1j * phi) * KET[("3/2", -1.5)]


def rank2_minimizer(p, phi=0.0):
    """Rank-two minimizer at <J> = 0 with spectrum (p, 1-p), quantized along z."""
    u = (1 + 2 * p) / (4 * p)
    a = np.sqrt(u) * KET[("-", 0.5)] + np.sqrt(1 - u) * np.exp(1j * phi) * KET[("3/2", -1.5)]
    b = KET[("-", -0.5)]
    return p * np.outer(a, a.conj()) + (1 - p) * np.outer(b, b.conj())
