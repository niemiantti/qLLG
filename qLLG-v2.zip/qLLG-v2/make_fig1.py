#!/usr/bin/env python3
"""Fig. 1 of the draft from the data of run_tables.py (data/table_S1.npz, S2, S3).

(a) E_min(q) for beta eps = 1/2, 1, 2, 4 and T = 0 with the attractor energies of Table S1;
(b) ||D_t rho|| (solid) and ||rho_dot|| (dashed) for the six runs of Table S2 at q = 0, 0.2, 0.4;
(c) observables after relaxation: top, Gibbs orbit at beta eps = 1, q = 0.2; bottom, exchange-
    shifted orbit, Delta = 6 eps, q = 0.2.
Output: figures/fig1.pdf and figures/fig1.png.
"""
import os
import sys

import numpy as np
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from qllg.trimer import EPS, SIG, SIGP, expval, qmax_gibbs, hamiltonian
from qllg.theory import emin_gibbs
from qllg.flow import propagate

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, "data")
OUT = os.path.join(HERE, "figures")
os.makedirs(OUT, exist_ok=True)

BLUE, ORANGE, GREEN, INK, GREY = "#2a78d6", "#eb6834", "#2a9d5c", "#0b0b0b", "#52514e"
plt.rcParams.update({
    "font.family": "serif", "font.serif": ["cmr10", "DejaVu Serif"], "mathtext.fontset": "cm",
    "axes.formatter.use_mathtext": True, "font.size": 7.5, "axes.labelsize": 7.5,
    "xtick.labelsize": 6.5, "ytick.labelsize": 6.5, "axes.linewidth": 0.5, "legend.fontsize": 6,
    "xtick.major.width": 0.5, "ytick.major.width": 0.5, "xtick.major.size": 2.5, "ytick.major.size": 2.5,
    "xtick.direction": "in", "ytick.direction": "in", "pdf.fonttype": 42,
})

from qllg.data import load_table
R1, J1 = load_table("S1", DATA)
R2, _ = load_table("S2", DATA)
R3, _ = load_table("S3", DATA)

fig = plt.figure(figsize=(7.0, 2.35))
gs = GridSpec(2, 3, figure=fig, left=0.075, right=0.985, bottom=0.17, top=0.95, wspace=0.42, hspace=0.55,
              width_ratios=[1, 1, 1.05])
axA = fig.add_subplot(gs[:, 0])
axB = fig.add_subplot(gs[:, 1])
axC1 = fig.add_subplot(gs[0, 2])
axC2 = fig.add_subplot(gs[1, 2])

# ------------------------------------------------------------------ (a) E_min(q) and the attractors
qq = np.linspace(0, 1, 2)
axA.plot(qq, -qq / 2, color=GREY, lw=0.6, ls=(0, (3, 2)), zorder=1)
LABELS = {0.5: (r"$\beta\varepsilon=\frac{1}{2}$", (0.03, 0.02), "left", "bottom"), 1.0: ("1", (0.03, 0.02), "left", "bottom"),
          2.0: ("2", (0.03, 0.02), "left", "bottom"), 4.0: ("4", (-0.025, 0.035), "right", "bottom"),
          np.inf: (r"$T=0$", (0.0, -0.045), "center", "top")}
for be in (0.5, 1.0, 2.0, 4.0, np.inf):
    beta = be / EPS
    qm = qmax_gibbs(beta)
    q = np.linspace(0, qm, 50)
    axA.plot(q, emin_gibbs(q, beta) / EPS, color=BLUE if np.isfinite(be) else INK, lw=0.8, zorder=2)
    axA.plot([0], [emin_gibbs(0, beta) / EPS], "o", mfc="white", mec=BLUE, ms=4, mew=0.8, zorder=4)
    axA.plot([qm], [emin_gibbs(qm, beta) / EPS], "s", color=BLUE, ms=4, zorder=4)
    lab, (dx, dy), ha, va = LABELS[be]
    axA.text(qm + dx, emin_gibbs(qm, beta) / EPS + dy, lab, fontsize=6.5, ha=ha, va=va)
for d in J1:
    axA.plot(d["q"], d["E_over_eps"], ".", color=INK, ms=4, zorder=5)
axA.set_xlim(-0.03, 1.1); axA.set_ylim(-1.06, 0.02)
# label of the dashed line, rotated with the line on the screen
p0 = axA.transData.transform((0.5, -0.25)); p1 = axA.transData.transform((0.7, -0.35))
ang = np.degrees(np.arctan2(p1[1] - p0[1], p1[0] - p0[0]))
axA.text(0.625, -0.305, r"$E=-\varepsilon q/2$", color=GREY, fontsize=6, rotation=ang, ha="center", va="bottom", rotation_mode="anchor")
axA.set_xlabel(r"charge $q=|\langle\mathbf{J}\rangle|$", labelpad=1)
axA.set_ylabel(r"energy $E/\varepsilon$", labelpad=1)
axA.set_xticks([0, 0.25, 0.5, 0.75, 1.0]); axA.set_yticks([-1, -0.75, -0.5, -0.25, 0])
h1 = axA.plot([], [], "o", mfc="white", mec=BLUE, ms=4, mew=0.8, label="Gibbs state")[0]
h2 = axA.plot([], [], "s", color=BLUE, ms=4, label="fully exchanged")[0]
h3 = axA.plot([], [], ".", color=INK, ms=4, label="attractors")[0]
axA.legend(handles=[h1, h2, h3], loc="lower right", frameon=False, handletextpad=0.3, borderpad=0.2)
axA.text(-0.12, 1.02, "(a)", transform=axA.transAxes, fontweight="bold", fontsize=8)

# ------------------------------------------------------------------ (b) velocities, Table S2 runs
cols = {0.0: BLUE, 0.2: ORANGE, 0.4: GREEN}
for run in R2[:6]:
    q = round(float(np.linalg.norm(run["q"][0])), 1)
    axB.semilogy(run["t"], run["normRhoDot"], color=cols[q], lw=0.7, ls=(0, (2.5, 1.5)), zorder=2)
    axB.semilogy(run["t"], run["normD"], color=cols[q], lw=0.9, zorder=3)
axB.set_xlim(0, 600); axB.set_ylim(1e-11, 3)
axB.set_yticks([1e-10, 1e-8, 1e-6, 1e-4, 1e-2, 1e0]); axB.minorticks_off()
axB.set_xticks([0, 200, 400, 600])
axB.set_xlabel(r"$\omega t$", labelpad=1)
axB.set_ylabel(r"$\Vert\mathcal{D}_t\rho\Vert$ (solid), $\Vert\dot\rho\Vert$ (dashed)", labelpad=1)
axB.text(470, 10 ** -0.35, r"$q=0.2$", fontsize=6.5, color=ORANGE)
axB.text(470, 10 ** -1.55, r"$q=0.4$", fontsize=6.5, color=GREEN)
axB.text(200, 10 ** -8.6, r"$q=0$", fontsize=6.5, color=BLUE)
axB.text(-0.12, 1.02, "(b)", transform=axB.transAxes, fontweight="bold", fontsize=8)

# ------------------------------------------------------------------ (c) observables after relaxation
T_GIBBS = 2 * np.pi / EPS           # period 2 pi / (sqrt3 omega)
T_EXCH = np.pi / EPS                # period pi / (sqrt3 omega)
times = np.linspace(0, 7.5, 751)

W = R2[2]["W_end"]                  # first run at q = 0.2 of Table S2 (Gibbs orbit, beta eps = 1)
rhos = propagate(W @ W.conj().T, hamiltonian(0.0), times)
s1z = [expval(r, SIG[0][2]) for r in rhos]
s1x = [expval(r, SIG[0][0]) for r in rhos]
c12 = [np.trace(r @ SIGP[0] @ SIGP[1]).real for r in rhos]
axC1.plot(times, s1z, color=GREEN, lw=0.9)
axC1.plot(times, s1x, color=ORANGE, lw=0.9)
axC1.plot(times, c12, color=BLUE, lw=0.9)
axC1.set_xlim(0, 7.5); axC1.set_ylim(-0.14, 0.2)
axC1.set_yticks([-0.1, 0, 0.1, 0.2])
axC1.set_xticks([0, 2, 4, 6])
axC1.text(0.1, 0.165, "Gibbs orbit", fontsize=6)
axC1.text(6.3, 0.145, r"$\langle\sigma_1^z\rangle$", fontsize=6, color=GREEN)
axC1.text(6.3, 0.012, r"$\langle\sigma_1^x\rangle$", fontsize=6, color=ORANGE)
axC1.text(1.5, 0.062, r"$\mathrm{Re}\langle\sigma_1^+\sigma_2^+\rangle$", fontsize=6, color=BLUE)
axC1.annotate("", xy=(T_GIBBS, -0.12), xytext=(0, -0.12), arrowprops=dict(arrowstyle="<->", lw=0.6, color=INK))
axC1.text(T_GIBBS / 2, -0.105, r"$2\pi/\sqrt{3}\,\omega$", fontsize=5.5, ha="center", va="bottom")
axC1.tick_params(labelbottom=False)
axC1.text(-0.2, 1.05, "(c)", transform=axC1.transAxes, fontweight="bold", fontsize=8)

W = R3[2]["W_end"]                  # first run at q = 0.2 of Table S3 (Delta = 6 eps)
rhos = propagate(W @ W.conj().T, hamiltonian(6.0 * EPS), times)
sx = np.array([[expval(r, SIG[i][0]) for i in range(3)] for r in rhos])
for i, c in enumerate((BLUE, ORANGE, GREEN)):
    axC2.plot(times, sx[:, i], color=c, lw=0.9, label=rf"$\langle\sigma_{i + 1}^x\rangle$")
axC2.plot(times, sx.sum(axis=1), color=INK, lw=0.7, ls=(0, (2.5, 1.5)), label=r"$\sum_i\langle\sigma_i^x\rangle$")
axC2.set_xlim(0, 7.5); axC2.set_ylim(-0.33, 0.33)
axC2.set_yticks([-0.2, 0, 0.2])
axC2.text(0.1, 0.25, r"exchange, $\Delta=6\varepsilon$", fontsize=6)
axC2.annotate("", xy=(T_EXCH, -0.3), xytext=(0, -0.3), arrowprops=dict(arrowstyle="<->", lw=0.6, color=INK))
axC2.text(T_EXCH + 0.15, -0.3, r"$\pi/\sqrt{3}\,\omega$", fontsize=5.5, ha="left", va="center")
axC2.legend(loc="upper right", ncol=4, frameon=False, handlelength=1.2, columnspacing=0.6, handletextpad=0.3,
            bbox_to_anchor=(1.03, 1.36))
axC2.set_xlabel(r"$\omega\,(t-t_{\rm end})$", labelpad=1)
axC2.set_xticks([0, 2, 4, 6])

for ext in ("pdf", "png"):
    fig.savefig(os.path.join(OUT, f"fig1.{ext}"), dpi=400)
print("wrote figures/fig1.pdf and figures/fig1.png")
