"""Analytic results of the draft for the Gibbs orbit and the exchange-shifted orbit.

All formulas refer to the charge direction n = z and to the joint basis of trimer.BASIS.
Units hbar = omega = 1, eps = sqrt(3).
"""
import numpy as np
from scipy.optimize import minimize

from .trimer import (EPS, KET, IDX, BASIS, ENERGY, MVAL, H, J, J2, SIG, SIGP, P_MINUS, P_QUAD,
                     P_PLUS, V_JOINT, comm, charge, expval, hs_norm, to_joint, from_joint,
                     gibbs_weights, gibbs_state, gibbs_energy, hamiltonian, qmax_gibbs)

# the two level pairs that cross at lambda = -eps/2, Eq. (S21)
PAIR_A = (("-", -0.5), ("3/2", 1.5))
PAIR_B = (("3/2", -1.5), ("+", 0.5))
# the doublet pair that crosses at lambda = -2 eps on the strong-exchange branch, Eq. (S42)
PAIR_C = (("-", -0.5), ("+", 0.5))


# ------------------------------------------------------------------ Gibbs orbit, Secs. S5-S7
def emin_gibbs(q, beta):
    """E_min(q) = eps [q/2 - tanh(beta eps/2)], 0 <= q <= tanh(beta eps/2), Eq. (S28);
    at T = 0 (beta = inf): -eps + eps q/2 on [0, 1], Eq. (S38)."""
    q = np.asarray(q, float)
    return EPS * (q / 2 - qmax_gibbs(beta))


def passive_value(spectrum, K):
    """P[K] = sum_k p_k^(down) kappa_k^(up), Eq. (S16): the minimum of Tr(rho K) on the orbit."""
    p = np.sort(np.asarray(spectrum, float))[::-1]
    kap = np.sort(np.linalg.eigvalsh(K))
    return float(p @ kap)


def dual_function(lam, beta, delta=0.0, n=(0, 0, 1)):
    """P(lambda) = P[H + lambda n.J] on the Gibbs orbit, Eq. (S18); analytic form (S22) for
    delta = 0."""
    from .trimer import spectrum_vector
    K = hamiltonian(delta) + lam * sum(ni * Ja for ni, Ja in zip(n, J))
    return passive_value(spectrum_vector(beta, delta), K)


def dual_function_analytic(lam, beta):
    """Eq. (S22): P(lambda) = E_G for |lambda| <= eps/2, E_G + (eps/2 - |lambda|) q_max beyond."""
    EG = gibbs_energy(beta)
    qm = qmax_gibbs(beta)
    lam = np.asarray(lam, float)
    return np.where(np.abs(lam) <= EPS / 2, EG, EG + (EPS / 2 - np.abs(lam)) * qm)


def charges_AB(beta):
    """q_A = 2(p_- - p_0), q_B = 2(p_0 - p_+), Eq. (S31)."""
    pm, p0, pp = gibbs_weights(beta)
    return 2 * (pm - p0), 2 * (p0 - pp)


def family_state(beta, theta, vartheta, phi=0.0, varphi=0.0):
    """The minimizer rho_*(theta, vartheta, phi, varphi) of Eqs. (S25)-(S26) [Eq. (20) of the
    draft] in the product basis.  At T = 0 the rank-two state (S38)."""
    pm, p0, pp = gibbs_weights(beta)
    a = np.cos(theta) * KET[PAIR_A[0]] + np.exp(1j * phi) * np.sin(theta) * KET[PAIR_A[1]]
    b = np.cos(vartheta) * KET[PAIR_B[0]] + np.exp(1j * varphi) * np.sin(vartheta) * KET[PAIR_B[1]]
    PA0 = np.outer(KET[PAIR_A[0]], KET[PAIR_A[0]].conj())
    PB0 = np.outer(KET[PAIR_B[0]], KET[PAIR_B[0]].conj())
    rho = gibbs_state(beta) + (pm - p0) * (np.outer(a, a.conj()) - PA0) + (p0 - pp) * (np.outer(b, b.conj()) - PB0)
    return rho


def family_charge(beta, theta, vartheta):
    """q = 2(p_- - p_0) sin^2 theta + 2(p_0 - p_+) sin^2 vartheta, Eq. (S27)."""
    qA, qB = charges_AB(beta)
    return qA * np.sin(theta) ** 2 + qB * np.sin(vartheta) ** 2


def two_spin_band(q, beta):
    """Band of |<sigma_i^+ sigma_j^+>| over the admissible splits q_a + q_b = q, Eq. (S36).

    Returns (lower, upper) in units of 1/(2 sqrt 3) * [...] i.e. absolute values."""
    qA, qB = charges_AB(beta)
    if np.isinf(beta):                                     # T = 0: pair B absent
        v = np.sqrt(max(q * (1 - q), 0.0)) / (2 * np.sqrt(3))
        return v, v
    qa = np.linspace(max(0.0, q - qB), min(q, qA), 20001)
    qb = q - qa
    ra = np.sqrt(np.clip(qa * (qA - qa), 0, None))
    rb = np.sqrt(np.clip(qb * (qB - qb), 0, None))
    lo = np.abs(ra - rb).min() / (2 * np.sqrt(3))
    hi = (ra + rb).max() / (2 * np.sqrt(3))
    return float(lo), float(hi)


def two_spin_amplitude(beta, theta, vartheta, phi, varphi):
    """|<sigma_i^+ sigma_j^+>| of the family member, Eq. (S36) with the relative phase
    delta = phi - varphi + pi."""
    qA, qB = charges_AB(beta)
    qa, qb = qA * np.sin(theta) ** 2, qB * np.sin(vartheta) ** 2
    d = phi - varphi + np.pi
    return abs(np.sqrt(qa * (qA - qa)) + np.exp(1j * d) * np.sqrt(qb * (qB - qb))) / (2 * np.sqrt(3))


def rhodot_norm_prediction(beta, theta, vartheta):
    """||rho_dot_*||_HS = (eps/sqrt2) sqrt[q_a(q_A - q_a) + q_b(q_B - q_b)], Eq. (S37)."""
    qA, qB = charges_AB(beta)
    qa, qb = qA * np.sin(theta) ** 2, qB * np.sin(vartheta) ** 2
    return EPS / np.sqrt(2) * np.sqrt(qa * (qA - qa) + qb * (qB - qb))


# ------------------------------------------------------------------ fit of a state to the family
def read_angles(rho, beta):
    """sin^2 theta and sin^2 vartheta read off the populations of |3/2,3/2> and |+,1/2>,
    and the constraint residual delta_23 = q_A sin^2 theta + q_B sin^2 vartheta - q."""
    pm, p0, pp = gibbs_weights(beta)
    R = to_joint(rho)
    pA = np.real(R[IDX[PAIR_A[1]], IDX[PAIR_A[1]]])
    s2t = (pA - p0) / (pm - p0)
    if np.isinf(beta):
        s2v = 0.0
    else:
        pB = np.real(R[IDX[PAIR_B[1]], IDX[PAIR_B[1]]])
        s2v = (pB - pp) / (p0 - pp)
    q = np.linalg.norm(charge(rho))
    qA, qB = charges_AB(beta)
    return float(s2t), float(s2v), float(qA * s2t + qB * s2v - q)


def forbidden_coherence(rho):
    """Largest |matrix element| in the joint basis outside the diagonal and the two pair
    coherences A and B."""
    R = np.abs(to_joint(rho)).copy()
    np.fill_diagonal(R, 0.0)
    for pair in (PAIR_A, PAIR_B):
        i, j = IDX[pair[0]], IDX[pair[1]]
        R[i, j] = R[j, i] = 0.0
    return float(R.max())


def fit_family(rho, beta):
    """r_fam = min ||rho - rho_*(theta, vartheta, phi, varphi)||_HS and the fitted angles.

    The initial guess is read off the populations and the pair coherences; the residual is then
    minimized numerically over all four angles."""
    s2t, s2v, _ = read_angles(rho, beta)
    R = to_joint(rho)
    cA = R[IDX[PAIR_A[1]], IDX[PAIR_A[0]]]           # <3/2,3/2| rho |-,-1/2>  ~ sin cos e^{i phi}
    cB = R[IDX[PAIR_B[1]], IDX[PAIR_B[0]]]
    x0 = np.array([np.arcsin(np.sqrt(np.clip(s2t, 0, 1))), np.arcsin(np.sqrt(np.clip(s2v, 0, 1))),
                   np.angle(cA), np.angle(cB)])

    def res(x):
        return hs_norm(rho - family_state(beta, *x))

    best = minimize(res, x0, method="Nelder-Mead", options={"xatol": 1e-12, "fatol": 1e-14, "maxiter": 4000})
    x = best.x
    return float(best.fun), x


def fit_exchange_branch(rho, beta, delta):
    """Single-block fit to the doublet-mixing branch (S42): r = min ||rho - rho_*(chi, eta)||."""
    R = to_joint(rho)
    c = R[IDX[PAIR_C[1]], IDX[PAIR_C[0]]]
    pm, p0, pp = gibbs_weights(beta, delta)
    pC = np.real(R[IDX[PAIR_C[1]], IDX[PAIR_C[1]]])
    s2c = np.clip((pC - pp) / (pm - pp), 0, 1)
    x0 = np.array([np.arcsin(np.sqrt(s2c)), np.angle(c)])

    def res(x):
        return hs_norm(rho - exchange_state(beta, delta, *x))

    best = minimize(res, x0, method="Nelder-Mead", options={"xatol": 1e-12, "fatol": 1e-14, "maxiter": 4000})
    return float(best.fun), best.x


# ------------------------------------------------------------------ exchange-shifted orbit, Sec. S9
def exchange_state(beta, delta, chi, eta=0.0):
    """rho_* of Eq. (S42): rho_G + (p_- - p_+)(|c><c| - P_{-,-1/2}),
    |c> = cos chi |-,-1/2> + e^{i eta} sin chi |+,+1/2>."""
    pm, p0, pp = gibbs_weights(beta, delta)
    c = np.cos(chi) * KET[PAIR_C[0]] + np.exp(1j * eta) * np.sin(chi) * KET[PAIR_C[1]]
    P0 = np.outer(KET[PAIR_C[0]], KET[PAIR_C[0]].conj())
    return gibbs_state(beta, delta) + (pm - pp) * (np.outer(c, c.conj()) - P0)


def emin_exchange(q, beta, delta):
    """E_min(q) on the exchange-shifted orbit for Delta > 5 eps, Eq. (S44) (segments of
    capacity c, 2d, c, d with slopes 2eps, (Delta - eps)/2, Delta - eps, Delta + eps)."""
    pm, p0, pp = gibbs_weights(beta, delta)
    c, d = pm - pp, pp - p0
    q = np.asarray(q, float)
    pos = lambda x: np.clip(x, 0, None)
    EG = gibbs_energy(beta, delta)
    return (EG + 2 * EPS * q + (delta - 5 * EPS) / 2 * pos(q - c) + (delta - EPS) / 2 * pos(q - c - 2 * d)
            + 2 * EPS * pos(q - 2 * c - 2 * d))


def qcap_exchange(beta, delta):
    """Orbit bound 2c + 3d = 2p_- + p_+ - 3p_0 of Corollary 2 for the exchange-shifted spectrum."""
    pm, p0, pp = gibbs_weights(beta, delta)
    return 2 * pm + pp - 3 * p0


def emin_weak_exchange(q, beta, delta):
    """E_min(q) for 0 <= Delta < eps, Eq. (S47)."""
    pm, p0, pp = gibbs_weights(beta, delta)
    qB, qmax = 2 * (p0 - pp), 2 * (pm - pp)
    EG = gibbs_energy(beta, delta)
    q = np.asarray(q, float)
    return np.where(q <= qB, EG + (EPS - delta) / 2 * q,
                    EG + (EPS - delta) / 2 * qB + (EPS + delta) / 2 * (q - qB))


# ------------------------------------------------------------------ independent constrained minimization
def constrained_minimum(spectrum, q, delta=0.0, restarts=8, seed=0, n=(0, 0, 1), rho0=None, pol=1e-9):
    """Direct numerical minimization of <H_Delta> over the orbit of the given spectrum at charge
    q n, by SLSQP over U = exp(i A), A Hermitian (64 real parameters).  Independent of the flow
    and of the analytic minimizers; used only for verification.  Returns (E, rho)."""
    rng = np.random.default_rng(seed)
    Hd = hamiltonian(delta)
    spectrum = np.asarray(spectrum, float)
    if len(spectrum) < 8:
        spectrum = np.concatenate([spectrum, np.zeros(8 - len(spectrum))])
    if rho0 is None:
        rho0 = np.diag(spectrum).astype(complex)        # any state with the spectrum
        # place the populations on the joint basis in energy order (passive state of H)
        order = np.argsort(np.linalg.eigvalsh(Hd))
        rho0 = from_joint(np.diag(spectrum[np.argsort(-spectrum)]))
    target = q * np.asarray(n, float)
    iu = np.triu_indices(8, 1)

    def unitary(x):
        A = np.diag(x[:8]).astype(complex)
        A[iu] = x[8:36] + 1j * x[36:64]
        A = A + np.triu(A, 1).conj().T
        from scipy.linalg import expm
        return expm(1j * A)

    def state(x):
        U = unitary(x)
        return U @ rho0 @ U.conj().T

    f = lambda x: expval(state(x), Hd)
    cons = [{"type": "eq", "fun": lambda x: charge(state(x)) - target}]
    best = None
    for k in range(restarts):
        x0 = rng.normal(size=64) * (0.0 if k == 0 else 1.0)
        s = minimize(f, x0, method="SLSQP", constraints=cons, options={"ftol": 1e-14, "maxiter": 3000})
        viol = np.linalg.norm(charge(state(s.x)) - target)
        if viol < 1e-7 and (best is None or s.fun < best[0]):
            best = (float(s.fun), state(s.x))
    return best
