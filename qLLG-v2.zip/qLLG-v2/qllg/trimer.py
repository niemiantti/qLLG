"""The chiral spin trimer: operators, joint eigenbasis, Gibbs weights and the exchange shift.

Units: hbar = omega = 1, so that eps = sqrt(3).  The model is

    H   = (1/2) sigma_1 . (sigma_2 x sigma_3),      J_a = (1/2) sum_i sigma_i^a,
    [H, J_a] = 0,   [J_a, J_b] = i eps_abc J_c,

on the eight-dimensional product space of three spins-1/2 (site 1 is the leftmost
factor of the Kronecker product, |up> = (1, 0)).  The spectrum of H is
-eps (doublet |->), 0 (quadruplet |3/2>), +eps (doublet |+>).

The joint eigenbasis |mu, m> of H and J_z follows the conventions of the draft:
|3/2, 3/2> = |up up up>, |-, -1/2> = (|dd u> + w3 |d u d> + w3^2 |u d d>)/sqrt(3) with
w3 = exp(2 pi i / 3), the positive-chirality doublet by the exchange w3 <-> w3^2, and the
remaining states by the ladder operators with Condon-Shortley phases (positive coefficients).

The optional isotropic Heisenberg exchange shifts the quadruplet by the gap Delta,
H_Delta = H + Delta P_Q, with energies measured from the centre of the two doublets.
"""
import numpy as np

EPS = np.sqrt(3.0)          # eps = sqrt(3) hbar omega with hbar = omega = 1
HBAR = 1.0
OMEGA = 1.0

# ------------------------------------------------------------------ Pauli matrices, sites
_sx = np.array([[0, 1], [1, 0]], complex)
_sy = np.array([[0, -1j], [1j, 0]], complex)
_sz = np.array([[1, 0], [0, -1]], complex)
_I2 = np.eye(2, dtype=complex)


def _site(op, i):
    mats = [_I2, _I2, _I2]
    mats[i] = op
    return np.kron(np.kron(mats[0], mats[1]), mats[2])


SIG = [[_site(s, i) for s in (_sx, _sy, _sz)] for i in range(3)]   # SIG[i][a]: Pauli a on site i
LEVI = np.zeros((3, 3, 3))
for _a, _b, _c in [(0, 1, 2), (1, 2, 0), (2, 0, 1)]:
    LEVI[_a, _b, _c], LEVI[_b, _a, _c] = 1.0, -1.0
CHI = sum(LEVI[a, b, c] * SIG[0][a] @ SIG[1][b] @ SIG[2][c]
          for a in range(3) for b in range(3) for c in range(3) if LEVI[a, b, c])
H = 0.5 * OMEGA * CHI                                               # scalar-chirality Hamiltonian
J = [0.5 * (SIG[0][a] + SIG[1][a] + SIG[2][a]) for a in range(3)]   # total spin
J2 = sum(Ja @ Ja for Ja in J)
JP = J[0] + 1j * J[1]                                               # J_+
JM = J[0] - 1j * J[1]                                               # J_-
ID8 = np.eye(8, dtype=complex)

# cyclic permutation of the sites 1 -> 2 -> 3 -> 1 (C3 |s1 s2 s3> = |s3 s1 s2>)
C3 = np.zeros((8, 8), complex)
for _s in range(8):
    _b = [(_s >> 2) & 1, (_s >> 1) & 1, _s & 1]
    _t = (_b[2] << 2) | (_b[0] << 1) | _b[1]
    C3[_t, _s] = 1.0
# transposition of sites 2 and 3
P23 = np.kron(_I2, np.array([[1, 0, 0, 0], [0, 0, 1, 0], [0, 1, 0, 0], [0, 0, 0, 1]], complex))


def comm(A, B):
    return A @ B - B @ A


def expval(rho, A):
    """Real part of Tr(rho A)."""
    return float(np.real(np.trace(rho @ A)))


def charge(rho):
    """The charge vector <J> = (Tr rho J_x, Tr rho J_y, Tr rho J_z)."""
    return np.array([expval(rho, Ja) for Ja in J])


def hs_norm(A):
    """Hilbert-Schmidt (Frobenius) norm."""
    return float(np.linalg.norm(A))


# ------------------------------------------------------------------ joint eigenbasis (S3)-(S4)
W3 = np.exp(2j * np.pi / 3)


def _ket(bits):
    """Product state |s1 s2 s3> with bits in {'u','d'}."""
    v = np.zeros(8, complex)
    idx = 0
    for b in bits:
        idx = (idx << 1) | (0 if b == 'u' else 1)
    v[idx] = 1.0
    return v


def _build_joint_basis():
    kets = {}
    kets[("3/2", 1.5)] = _ket("uuu")
    for m in (0.5, -0.5, -1.5):                      # quadruplet by J_- with positive coefficients
        v = JM @ kets[("3/2", m + 1)]
        kets[("3/2", m)] = v / np.linalg.norm(v)
    kets[("-", -0.5)] = (_ket("ddu") + W3 * _ket("dud") + W3 ** 2 * _ket("udd")) / np.sqrt(3)
    kets[("+", -0.5)] = (_ket("ddu") + W3 ** 2 * _ket("dud") + W3 * _ket("udd")) / np.sqrt(3)
    for mu in ("-", "+"):                            # doublets by J_+ with positive coefficients
        v = JP @ kets[(mu, -0.5)]
        kets[(mu, 0.5)] = v / np.linalg.norm(v)
    return kets


KET = _build_joint_basis()
# ordering of the joint basis used for matrices "in the joint basis"
BASIS = [("-", 0.5), ("-", -0.5), ("3/2", 1.5), ("3/2", 0.5), ("3/2", -0.5), ("3/2", -1.5),
         ("+", 0.5), ("+", -0.5)]
LEVEL = {"-": -EPS, "3/2": 0.0, "+": EPS}
ENERGY = np.array([LEVEL[mu] for mu, m in BASIS])
MVAL = np.array([m for mu, m in BASIS])
V_JOINT = np.column_stack([KET[k] for k in BASIS])   # columns: joint basis in the product basis
IDX = {k: i for i, k in enumerate(BASIS)}


def to_joint(A):
    """Matrix elements of A in the joint basis (rows/columns ordered as BASIS)."""
    return V_JOINT.conj().T @ A @ V_JOINT


def from_joint(A):
    return V_JOINT @ A @ V_JOINT.conj().T


def proj(*keys):
    """Projector on the listed joint eigenstates."""
    return sum(np.outer(KET[k], KET[k].conj()) for k in keys)


P_MINUS = proj(("-", 0.5), ("-", -0.5))
P_QUAD = proj(("3/2", 1.5), ("3/2", 0.5), ("3/2", -0.5), ("3/2", -1.5))
P_PLUS = proj(("+", 0.5), ("+", -0.5))

# single-site raising operators relative to n = z:  sigma_i^+ = (sigma_i^x + i sigma_i^y)/2
SIGP = [0.5 * (SIG[i][0] + 1j * SIG[i][1]) for i in range(3)]
SIGM = [0.5 * (SIG[i][0] - 1j * SIG[i][1]) for i in range(3)]


# ------------------------------------------------------------------ Gibbs orbit, exchange shift
def hamiltonian(delta=0.0):
    """H_Delta = H + Delta P_Q (Delta = 0 gives the bare chirality Hamiltonian)."""
    return H + delta * P_QUAD


def gibbs_weights(beta, delta=0.0):
    """Eigenvalues (p_-, p_0, p_+) of the Gibbs state of H_Delta, Eqs. (S11) and (S40).

    beta = numpy.inf gives the T = 0 limit (1/2, 0, 0)."""
    if np.isinf(beta):
        return 0.5, 0.0, 0.0
    Z = 2 * np.exp(beta * EPS) + 4 * np.exp(-beta * delta) + 2 * np.exp(-beta * EPS)
    return np.exp(beta * EPS) / Z, np.exp(-beta * delta) / Z, np.exp(-beta * EPS) / Z


def gibbs_state(beta, delta=0.0):
    pm, p0, pp = gibbs_weights(beta, delta)
    return pm * P_MINUS + p0 * P_QUAD + pp * P_PLUS


def spectrum_vector(beta, delta=0.0):
    """The prescribed spectrum P = diag(p_-, p_-, p_0, p_0, p_0, p_0, p_+, p_+) (eight entries),
    or diag(1/2, 1/2) (two entries) at T = 0."""
    pm, p0, pp = gibbs_weights(beta, delta)
    if np.isinf(beta):
        return np.array([0.5, 0.5])
    return np.array([pm, pm, p0, p0, p0, p0, pp, pp])


def gibbs_energy(beta, delta=0.0):
    """E_G = <H_Delta>_G measured from the centre of the doublets, Eqs. (S12) and (S40)."""
    pm, p0, pp = gibbs_weights(beta, delta)
    return -2 * EPS * (pm - pp) + 4 * delta * p0


def qmax_gibbs(beta):
    """Largest charge on the Gibbs orbit of H, Eq. (S17): tanh(beta eps / 2) = 2(p_- - p_+)."""
    return 1.0 if np.isinf(beta) else float(np.tanh(beta * EPS / 2))
