"""Diagnostics of a finished run: the columns of Tables S1-S3 of the draft."""
import numpy as np

from .trimer import (EPS, SIG, SIGP, J, IDX, comm, charge, expval, hs_norm, to_joint,
                     gibbs_weights, gibbs_state, hamiltonian)
from .theory import (emin_gibbs, emin_exchange, read_angles, forbidden_coherence, fit_family,
                     fit_exchange_branch, two_spin_band, rhodot_norm_prediction, PAIR_C)
from .flow import decay_rate, propagate


def _final_state(run):
    Wend = run["W"][-1]
    return Wend @ Wend.conj().T


def fitted_rates(run):
    """Asymptotic decay rate of ||D_t rho|| (Sec. S10 d): least-squares slope of -ln||D|| over
    1e-8 <= ||D|| <= 1e-6, or over the last two decades above the final value when the run ends
    above 1e-8.  Also the early-stage rate over 1e-5 <= ||D|| <= 1e-3 and a flag marking a
    two-stage decay (rates differing by more than 20 per cent; the q = 0 runs)."""
    t, nD = run["t"], run["normD"]
    rate, window = decay_rate(t, nD, window=(1e-8, 1e-6))
    if not np.isfinite(rate):
        rate, window = decay_rate(t, nD)
    rate_early, _ = decay_rate(t, nD, window=(1e-5, 1e-3))
    # the q = 0 runs (charge below 1e-10) decay in two stages; their tabulated rate is the final one
    two_stage = bool(np.linalg.norm(run["q"][0]) < 1e-10)
    return rate, window, rate_early, two_stage


def run_summary(run):
    """Quantities that are constant or bounded along the whole run (captions of S1-S3)."""
    qn = np.linalg.norm(run["q"], axis=1)
    lam = np.linalg.norm(run["lam"], axis=1)
    return {
        "spec_dev_max": float(run["spec_dev"].max()),
        "charge_dev_max": float(np.abs(run["q"] - run["q"][0]).max()),
        "energy_monotone": bool(np.all(np.diff(run["E"]) <= 1e-11)),
        "energy_increase_max": float(max(0.0, np.diff(run["E"]).max())),
        "residual_max": float(run["residual"].max()),
        "normLamJ_max_over_eps": float(run["normLamJ"].max() / EPS),
        "lam_max_over_eps": float(lam.max() / EPS),
        "q_end": float(qn[-1]),
    }


def gibbs_orbit_diagnostics(run, beta, q):
    """Columns of Tables S1 and S2 for a run on the Gibbs orbit at inverse temperature beta."""
    rho = _final_state(run)
    E = run["E"][-1]
    lam = run["lam"][-1]
    lamn = np.linalg.norm(lam)
    s2t, s2v, d23 = read_angles(rho, beta)
    rfam, ang = fit_family(rho, beta)
    rate, window, rate_early, two_stage = fitted_rates(run)
    c12 = abs(np.trace(rho @ SIGP[0] @ SIGP[1]))
    band = two_spin_band(q, beta)
    sig = np.array([[expval(rho, SIG[i][a]) for a in range(3)] for i in range(3)])
    sigp = np.array([abs(np.trace(rho @ SIGP[i])) for i in range(3)])
    d = {
        "q": q, "E_over_eps": E / EPS, "dE_over_eps": (E - emin_gibbs(q, beta)) / EPS,
        "lam_abs_over_eps": lamn / EPS, "lam_z_dir": lam[2] / lamn if lamn > 0 else np.nan,
        "lam_dir_err": float(np.linalg.norm(lam / lamn - np.array([0, 0, -1.0]))) if lamn > 0 else np.nan,
        "sin2_theta": s2t, "sin2_vartheta": s2v if not np.isinf(beta) else np.nan, "delta23": d23,
        "forbidden": forbidden_coherence(rho), "r_fam": rfam, "normD_end": run["normD"][-1],
        "rate": rate, "rate_window": window, "rate_early": rate_early, "rate_two_stage": two_stage,
        "c12": c12, "band_lo": band[0], "band_hi": band[1],
        "normRhoDot_end": run["normRhoDot"][-1],
        "normRhoDot_pred": rhodot_norm_prediction(beta, ang[0], ang[1]),
        "moments_err": float(np.abs(sig - np.outer(np.full(3, 2 * q / 3), [0, 0, 1.0])).max()),
        "sigma_plus_max": float(sigp.max()),
        "rhoG_dist": hs_norm(rho - gibbs_state(beta)),
        "fit_angles": ang,
    }
    d.update(run_summary(run))
    return d


def exchange_orbit_diagnostics(run, beta, delta, q):
    """Columns of Table S3 for a run on the exchange-shifted orbit."""
    rho = _final_state(run)
    pm, p0, pp = gibbs_weights(beta, delta)
    E = run["E"][-1]
    lam = run["lam"][-1]
    lamn = np.linalg.norm(lam)
    R = to_joint(rho)
    iC0, iC1 = IDX[PAIR_C[0]], IDX[PAIR_C[1]]
    s2c = (np.real(R[iC1, iC1]) - pp) / (pm - pp)
    coh = abs(R[iC0, iC1])
    rfit, ang = fit_exchange_branch(rho, beta, delta)
    Rf = np.abs(R).copy()
    np.fill_diagonal(Rf, 0.0)
    Rf[iC0, iC1] = Rf[iC1, iC0] = 0.0
    sigp = np.array([np.trace(rho @ SIGP[i]) for i in range(3)])
    sigz = np.array([expval(rho, SIG[i][2]) for i in range(3)])
    c2 = max(abs(np.trace(rho @ SIGP[i] @ SIGP[j])) for i in range(3) for j in range(3) if i != j)
    rate, window, rate_early, two_stage = fitted_rates(run)
    phases = np.angle(sigp)
    steps = np.array([(phases[(i + 1) % 3] - phases[i]) for i in range(3)])
    steps = (steps + np.pi) % (2 * np.pi) - np.pi
    d = {
        "q": q, "E_over_eps": E / EPS, "dE_over_eps": (E - emin_exchange(q, beta, delta)) / EPS,
        "lam_abs_over_eps": lamn / EPS, "lam_z_dir": lam[2] / lamn if lamn > 0 else np.nan,
        "sin2_chi": s2c, "sin2_chi_pred": q / (pm - pp), "coh": coh,
        "coh_pred": np.sqrt(max(q * (pm - pp - q), 0.0)),
        "sigma_plus": float(np.abs(sigp).mean()), "sigma_plus_spread": float(np.abs(sigp).max() - np.abs(sigp).min()),
        "sigma_plus_pred": (2 / 3) * np.sqrt(max(q * (pm - pp - q), 0.0)),
        "sigma_plus_sum": float(abs(sigp.sum())),
        "phase_steps": steps, "sigma_z_err": float(np.abs(sigz - 2 * q / 3).max()),
        "two_spin_max": c2, "forbidden": float(Rf.max()), "r_fam": rfit, "normD_end": run["normD"][-1],
        "rate": rate, "rate_window": window, "rate_early": rate_early, "rate_two_stage": two_stage,
        "rhoG_dist": hs_norm(rho - gibbs_state(beta, delta)),
        "fit_angles": ang,
    }
    d.update(run_summary(run))
    return d


def observables_after_relaxation(run, delta, duration=7.5, n=751):
    """Free evolution of the final state over `duration` (units 1/omega): the signals of
    Fig. 1(c): <sigma_1^z>, <sigma_1^x>, Re<sigma_1^+ sigma_2^+> and <sigma_i^x> for i = 1, 2, 3."""
    rho_end = _final_state(run)
    times = np.linspace(0.0, duration, n)
    rhos = propagate(rho_end, hamiltonian(delta), times)
    s1z = np.array([expval(r, SIG[0][2]) for r in rhos])
    s1x = np.array([expval(r, SIG[0][0]) for r in rhos])
    c12 = np.array([np.trace(r @ SIGP[0] @ SIGP[1]) for r in rhos])
    sx = np.array([[expval(r, SIG[i][0]) for i in range(3)] for r in rhos])
    return {"t": times, "s1z": s1z, "s1x": s1x, "re_c12": c12.real, "c12": c12, "sx": sx}
