"""Covariant quantum Landau-Lifshitz-Gilbert (qLLG) flow of the trimer (Sec. S10 of the draft).

Equations (units hbar = omega = 1):

    i rho_dot   = [H + kappa D, rho],                 D = D_t rho,               (10)
    i D         = [H + lam.J + kappa D, rho].                                    (11)

In the eigenbasis rho = sum_k p_k |k><k| equation (11) is algebraic,

    D_kl = (H + lam.J)_kl (p_l - p_k) / [i - kappa (p_l - p_k)],                 (S48)

and affine in lam.  Charge conservation d<J_a>/dt = i kappa Tr(D [J_a, rho]) = 0 is a real
3 x 3 linear system M lam = -c, solved by minimum-norm least squares (singular values below
3 eps_mach times the largest are discarded).

The state is carried by Uhlmann amplitudes W (8 x r), rho = W W^dagger, W^dagger W = P, in
the gauge A = 0 with nu = 0:  i W_dot = (H + kappa D) W.  Because [H, J_a] = 0 the substitution
W = exp(-i H t) W_I removes the Hamiltonian rotation exactly,

    i W_I_dot = kappa D[rho_I] W_I,      rho(t) = exp(-i H t) rho_I(t) exp(i H t),

with the same multipliers; this is what is integrated (DOP853, rtol 1e-10, atol 1e-12).
"""
import numpy as np
from scipy.integrate import solve_ivp
from scipy.linalg import expm

from .trimer import H, J, EPS, comm, charge, expval, hs_norm, hamiltonian

RCOND = 3 * np.finfo(float).eps


# ------------------------------------------------------------------ covariant velocity (S48)
def covariant_velocity(rho, kappa, Hd=H, lam=None):
    """Return (D, lam, info) at the state rho.

    D   : the covariant velocity D_t rho (8 x 8 Hermitian) with the multipliers lam
    lam : the multipliers from charge conservation (unless given)
    info: dict with the 3 x 3 system (M, c), its residual ||M lam + c|| and the singular
          values of M.
    """
    p, V = np.linalg.eigh(rho)
    d = p[None, :] - p[:, None]                       # d_kl = p_l - p_k
    fac = d / (1j - kappa * d)
    Hk = V.conj().T @ Hd @ V
    Jk = [V.conj().T @ Ja @ V for Ja in J]
    D0 = Hk * fac
    Db = [Jb * fac for Jb in Jk]
    rk = np.diag(p).astype(complex)
    cJ = [comm(Ja, rk) for Ja in Jk]                  # [J_a, rho] in the eigenbasis
    c = np.array([np.real(1j * np.trace(D0 @ cj)) for cj in cJ])
    M = np.array([[np.real(1j * np.trace(Db[b] @ cJ[a])) for b in range(3)] for a in range(3)])
    if lam is None:
        lam = np.linalg.lstsq(M, -c, rcond=RCOND)[0]
    Dk = D0 + sum(l * Dbb for l, Dbb in zip(lam, Db))
    D = V @ Dk @ V.conj().T
    info = {"M": M, "c": c, "residual": float(np.linalg.norm(M @ lam + c)),
            "svals": np.linalg.svd(M, compute_uv=False)}
    return D, np.asarray(lam, float), info


def velocities(rho, kappa, Hd=H):
    """(D_t rho, rho_dot, lam) at rho:  rho_dot = -i [H + kappa D, rho]."""
    D, lam, info = covariant_velocity(rho, kappa, Hd)
    rho_dot = -1j * comm(Hd + kappa * D, rho)
    return D, rho_dot, lam


def pure_multiplier(psi, Q, Hd=H):
    """Eq. (15): lam = -(<HQ> - <H><Q>) / (<Q^2> - <Q>^2) for a pure state and one charge Q."""
    rho = np.outer(psi, psi.conj())
    cov = expval(rho, (Hd @ Q + Q @ Hd) / 2) - expval(rho, Hd) * expval(rho, Q)
    var = expval(rho, Q @ Q) - expval(rho, Q) ** 2
    return -cov / var


# ------------------------------------------------------------------ initial amplitudes
def haar_unitary(rng, n=8):
    """Haar-random n x n unitary from a complex Gaussian matrix (QR with phase correction)."""
    Z = (rng.normal(size=(n, n)) + 1j * rng.normal(size=(n, n))) / np.sqrt(2)
    Q, R = np.linalg.qr(Z)
    return Q * (np.diag(R) / np.abs(np.diag(R)))


def correct_charge(W, q, n=(0.0, 0.0, 1.0), tol=1e-13, maxit=200):
    """Damped Newton correction of <J> to q n along the orbit, preserving W^dagger W.

    The steps are W -> exp(-i s.X) W with the Hermitian generators X_a = i [rho, J_a], whose
    Jacobian is the (negative definite) Gram matrix G_ab = Tr([rho, J_a][rho, J_b]).
    Returns (W, |<J> - q n|, iterations)."""
    target = q * np.asarray(n, float) / np.linalg.norm(n)
    for it in range(maxit):
        rho = W @ W.conj().T
        F = charge(rho) - target
        err = np.linalg.norm(F)
        if err < tol:
            return W, err, it
        C = [comm(rho, Ja) for Ja in J]
        G = np.array([[np.real(np.trace(C[a] @ C[b])) for b in range(3)] for a in range(3)])
        s = np.linalg.lstsq(G, -F, rcond=1e-12)[0]
        X = sum(sa * 1j * Ca for sa, Ca in zip(s, C))      # Hermitian generator s.X
        step = 1.0
        while True:                                        # damping: accept only a decrease
            Wn = expm(-1j * step * X) @ W
            if np.linalg.norm(charge(Wn @ Wn.conj().T) - target) < err or step < 1e-6:
                break
            step /= 2
        W = Wn
    rho = W @ W.conj().T
    return W, float(np.linalg.norm(charge(rho) - target)), maxit


def initial_amplitude(rng, spectrum, q, n=(0.0, 0.0, 1.0)):
    """Random point on the orbit of the spectrum with charge q n.

    An 8 x 8 Haar-random unitary U is applied to the diagonal amplitudes, W(0) = U P^{1/2};
    for a rank-two spectrum (T = 0) only the first two columns are kept.  The charge is then
    imposed by the damped Newton correction along the orbit.  No information about the
    minimizers enters."""
    spectrum = np.asarray(spectrum, float)
    r = len(spectrum)
    U = haar_unitary(rng, 8)
    W = U[:, :r] @ np.diag(np.sqrt(spectrum))
    W, err, _ = correct_charge(W, q, n)
    return W, err


# ------------------------------------------------------------------ integration
def integrate(W0, kappa=0.5, t_end=600.0, n_out=1201, rtol=1e-10, atol=1e-12, delta=0.0):
    """Integrate the amplitude equation in the interaction picture from W0 to t_end.

    Returns a dict with the output times t, the interaction-picture amplitudes WI (n_out x 8 x r),
    the Schroedinger-picture amplitudes W, and the scalar diagnostics along the run:
    E, q (charge vectors), lam (multipliers), normD (||D_t rho||), normRhoDot (||rho_dot||),
    spec_dev (max deviation of the spectrum of W^dagger W from its initial value),
    residual (||M lam + c||), normLamJ (||lam^a [J_a, rho]||).
    """
    Hd = hamiltonian(delta)
    r = W0.shape[1]
    shape = (8, r)

    def rhs(t, y):
        WI = y.reshape(shape)
        D, _, _ = covariant_velocity(WI @ WI.conj().T, kappa, Hd)
        return (-1j * kappa * (D @ WI)).reshape(-1)

    t = np.linspace(0.0, t_end, n_out)
    sol = solve_ivp(rhs, (0.0, t_end), W0.reshape(-1).astype(complex), t_eval=t,
                    method="DOP853", rtol=rtol, atol=atol)
    if not sol.success:
        raise RuntimeError(sol.message)
    WI = sol.y.T.reshape(-1, *shape)
    eH, VH = np.linalg.eigh(Hd)
    out = {k: [] for k in ("E", "q", "lam", "normD", "normRhoDot", "spec_dev", "residual", "normLamJ")}
    spec0 = np.sort(np.linalg.eigvalsh(W0.conj().T @ W0))
    Ws = []
    for k in range(WI.shape[0]):
        Wk = WI[k]
        rhoI = Wk @ Wk.conj().T
        D, lam, info = covariant_velocity(rhoI, kappa, Hd)
        rho_dot = -1j * comm(Hd + kappa * D, rhoI)
        out["E"].append(expval(rhoI, Hd))
        out["q"].append(charge(rhoI))
        out["lam"].append(lam)
        out["normD"].append(hs_norm(D))
        out["normRhoDot"].append(hs_norm(rho_dot))
        out["spec_dev"].append(float(np.abs(np.sort(np.linalg.eigvalsh(Wk.conj().T @ Wk)) - spec0).max()))
        out["residual"].append(info["residual"])
        out["normLamJ"].append(hs_norm(sum(l * comm(Ja, rhoI) for l, Ja in zip(lam, J))))
        Ut = VH @ np.diag(np.exp(-1j * eH * t[k])) @ VH.conj().T
        Ws.append(Ut @ Wk)
    out = {k: np.array(v) for k, v in out.items()}
    out["t"] = t
    out["WI"] = WI
    out["W"] = np.array(Ws)
    out["kappa"], out["delta"], out["t_end"] = kappa, delta, t_end
    out["nfev"] = int(sol.nfev)
    return out


def decay_rate(t, normD, window=None, floor=1e-10, decades=2.0):
    """Asymptotic decay rate of ||D_t rho||: least-squares slope of -ln||D|| against t.

    By default the fit uses the last `decades` decades above max(floor, final value), i.e. the
    window 1e-8 <= ||D|| <= 1e-6 of Sec. S10 for a run that ends at 1e-8, the last two decades
    above the final value for a run that ends higher (beta eps = 4), and the final stage
    1e-10 <= ||D|| <= 1e-8 for a run that reaches the integration floor (q = 0).  An explicit
    window (lo, hi) can be given instead.  Returns (rate, (t_lo, t_hi))."""
    if window is None:
        lo = max(floor, normD[-1])
        hi = lo * 10 ** decades
    else:
        lo, hi = window
    mask = (normD >= lo) & (normD <= hi)
    # the descent through the window: the first contiguous stretch inside it (the noisy floor
    # of a q = 0 run can rise back into the window later on), starting at its maximum
    idx = np.where(mask)[0]
    if idx.size < 5:
        return np.nan, (np.nan, np.nan)
    breaks = np.where(np.diff(idx) > 1)[0]
    if breaks.size:
        idx = idx[:breaks[0] + 1]
    idx = idx[np.argmax(normD[idx]):]
    if idx.size < 5:
        return np.nan, (np.nan, np.nan)
    slope = np.polyfit(t[idx], -np.log(normD[idx]), 1)[0]
    return float(slope), (float(t[idx[0]]), float(t[idx[-1]]))


def propagate(rho, Hd, times):
    """Free von Neumann evolution rho(t) = exp(-i H t) rho exp(i H t) at the given times."""
    eH, VH = np.linalg.eigh(Hd)
    out = []
    for t in times:
        U = VH @ np.diag(np.exp(-1j * eH * t)) @ VH.conj().T
        out.append(U @ rho @ U.conj().T)
    return np.array(out)
