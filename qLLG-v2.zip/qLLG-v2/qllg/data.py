"""Loader for the data files written by run_tables.py."""
import json
import os

import numpy as np

KEYS = ("W0", "W_end", "WI_end", "t", "E", "q", "lam", "normD", "normRhoDot", "spec_dev", "residual",
        "normLamJ", "WI_coarse", "t_coarse")


def load_table(name, data_dir=None):
    """Return (runs, entries): runs is a list of dicts with the arrays of every run of Table `name`
    (keys as in KEYS; T = 0 amplitudes are zero-padded from 8x2 to 8x8), entries the list of
    table entries from the JSON file."""
    data_dir = data_dir or os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "data")
    z = np.load(os.path.join(data_dir, f"table_{name}.npz"))
    n = int(z["n_runs"])
    runs = [{key: z[f"r{k:02d}_{key}"] for key in KEYS} for k in range(n)]
    with open(os.path.join(data_dir, f"table_{name}.json")) as f:
        entries = json.load(f)
    return runs, entries
