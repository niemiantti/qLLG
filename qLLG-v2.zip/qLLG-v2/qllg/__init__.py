"""qllg: covariant quantum Landau-Lifshitz-Gilbert relaxation of a chiral spin trimer.

Simulation codes for the draft by Antti Niemi, "Quantum Hamiltonian time crystals from covariant
quantum Landau-Lifshitz-Gilbert relaxation".  Modules: trimer (model and basis), flow (the
covariant qLLG flow and its integration), theory (analytic results), diagnostics (table
columns), data (loader of the result files).
"""
__version__ = "2.0.0"
