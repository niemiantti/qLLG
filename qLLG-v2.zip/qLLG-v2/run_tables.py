#!/usr/bin/env python3
"""Run the covariant qLLG flow for every row of Tables S1-S3 of the draft and tabulate the
final states.

    python run_tables.py            # all three tables (about 2 minutes)
    python run_tables.py S1 S3      # a subset

Every table starts the pseudo-random generator at the seed 20261028 and draws one Haar-random
unitary per row, in the order of the rows (Sec. S10 d of the draft).  Outputs:

    data/table_S?.npz       initial and final amplitudes, scalar diagnostics along every run,
                            and the interaction-picture amplitudes W_I(t) every 5/omega
    tables/table_S?.csv     one row per run, all columns
    tables/table_S?.md      Markdown version of the printed table
    tables/table_S?.tex     LaTeX rows in the layout of the draft
"""
import os
import sys
import time
import json

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from qllg.trimer import EPS, spectrum_vector, gibbs_weights, qmax_gibbs
from qllg.flow import initial_amplitude, integrate
from qllg.diagnostics import gibbs_orbit_diagnostics, exchange_orbit_diagnostics
from qllg.theory import charges_AB
from tables_format import write_tables

SEED = 20261028
KAPPA = 0.5
HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, "data")
TABLES = os.path.join(HERE, "tables")

# ---------------------------------------------------------------- the rows of the tables
BETA_EPS_S1 = [0.5, 1.0, 2.0, 4.0, np.inf]          # np.inf = T = 0
FRACTIONS_S1 = [0.0, 0.2, 0.4, 0.6, 0.8, 0.97]


def rows_S1():
    for be in BETA_EPS_S1:
        beta = be / EPS
        for f in FRACTIONS_S1:
            yield {"beta_eps": be, "beta": beta, "q": f * qmax_gibbs(beta), "frac": f,
                   "t_end": 3000.0 if be == 4.0 else 600.0, "delta": 0.0}


def rows_S2():
    beta = 1.0 / EPS
    qA, qB = charges_AB(beta)
    for q in [0.0, 0.0, 0.2, 0.2, 0.4, 0.4, qA, qB]:
        yield {"beta_eps": 1.0, "beta": beta, "q": q, "t_end": 600.0, "delta": 0.0}


def rows_S3():
    beta = 1.0 / EPS
    for q in [0.0, 0.1, 0.2, 0.2, 0.3]:
        yield {"beta_eps": 1.0, "beta": beta, "q": q, "t_end": 600.0, "delta": 6.0 * EPS}


ROWS = {"S1": rows_S1, "S2": rows_S2, "S3": rows_S3}


def run_table(name, verbose=True):
    rng = np.random.default_rng(SEED)
    results, store = [], {"W0": [], "W_end": [], "WI_end": [], "t": [], "E": [], "q": [], "lam": [],
                          "normD": [], "normRhoDot": [], "spec_dev": [], "residual": [], "normLamJ": [],
                          "WI_coarse": [], "t_coarse": []}
    for k, row in enumerate(ROWS[name]()):
        P = spectrum_vector(row["beta"], row["delta"])
        W0, err0 = initial_amplitude(rng, P, row["q"])
        t0 = time.time()
        n_out = int(2 * row["t_end"]) + 1                       # output every 0.5/omega
        run = integrate(W0, kappa=KAPPA, t_end=row["t_end"], n_out=n_out, delta=row["delta"])
        if row["delta"] == 0.0:
            d = gibbs_orbit_diagnostics(run, row["beta"], row["q"])
        else:
            d = exchange_orbit_diagnostics(run, row["beta"], row["delta"], row["q"])
        d.update({"beta_eps": row["beta_eps"], "t_end": row["t_end"], "delta": row["delta"],
                  "charge_err_initial": err0, "nfev": run["nfev"], "seconds": time.time() - t0})
        results.append(d)
        for key in ("W0",):
            store[key].append(W0 if W0.shape[1] == 8 else np.pad(W0, ((0, 0), (0, 6))))
        Wend, WIend = run["W"][-1], run["WI"][-1]
        store["W_end"].append(Wend if Wend.shape[1] == 8 else np.pad(Wend, ((0, 0), (0, 6))))
        store["WI_end"].append(WIend if WIend.shape[1] == 8 else np.pad(WIend, ((0, 0), (0, 6))))
        for key in ("t", "E", "q", "lam", "normD", "normRhoDot", "spec_dev", "residual", "normLamJ"):
            store[key].append(run[key])
        WIc = run["WI"][::10]
        store["WI_coarse"].append(WIc if WIc.shape[2] == 8 else np.pad(WIc, ((0, 0), (0, 0), (0, 6))))
        store["t_coarse"].append(run["t"][::10])
        if verbose:
            if row["delta"] == 0.0:
                print(f"{name} row {k:2d}: beta*eps={row['beta_eps']:<4} q={row['q']:.4f}  E/eps={d['E_over_eps']:+.6f} "
                      f"dE={d['dE_over_eps']:+.1e} |lam|/eps={d['lam_abs_over_eps']:.6f} lam_z/|lam|={d['lam_z_dir']:+.4f} "
                      f"sin2={d['sin2_theta']:.4f},{d['sin2_vartheta']:.4f} rfam={d['r_fam']:.0e} "
                      f"||D||={d['normD_end']:.0e} rate={d['rate']:.4f} c12={d['c12']:.4f} band=[{d['band_lo']:.4f},{d['band_hi']:.4f}] "
                      f"{d['seconds']:.0f}s")
            else:
                print(f"{name} row {k:2d}: q={row['q']:.2f}  dE={d['dE_over_eps']:+.1e} |lam|/eps={d['lam_abs_over_eps']:.6f} "
                      f"sin2chi={d['sin2_chi']:.4f} ({d['sin2_chi_pred']:.4f}) coh={d['coh']:.4f} ({d['coh_pred']:.4f}) "
                      f"|s+|={d['sigma_plus']:.4f} ({d['sigma_plus_pred']:.4f}) rfam={d['r_fam']:.0e} ||D||={d['normD_end']:.0e} "
                      f"rate={d['rate']:.4f} {d['seconds']:.0f}s")
    os.makedirs(DATA, exist_ok=True)
    os.makedirs(TABLES, exist_ok=True)
    # one array per run and quantity (no pickled object arrays): r00_t, r00_E, ... ; see qllg/data.py
    packed = {}
    nruns = len(results)
    for key, val in store.items():
        for k in range(nruns):
            packed[f"r{k:02d}_{key}"] = np.asarray(val[k])
    packed["n_runs"] = np.array(nruns)
    np.savez_compressed(os.path.join(DATA, f"table_{name}.npz"), **packed)
    with open(os.path.join(DATA, f"table_{name}.json"), "w") as f:
        json.dump([{k: (v.tolist() if isinstance(v, np.ndarray) else (float(v) if isinstance(v, (np.floating, float)) else v))
                    for k, v in d.items() if k != "fit_angles"} | {"fit_angles": list(map(float, d["fit_angles"]))}
                   for d in results], f, indent=1)
    write_tables(name, results, TABLES)
    return results


if __name__ == "__main__":
    names = [a for a in sys.argv[1:] if a in ROWS] or ["S1", "S2", "S3"]
    for name in names:
        t0 = time.time()
        print(f"=== Table {name} ===")
        run_table(name)
        print(f"Table {name} done in {time.time() - t0:.0f} s; files in data/ and tables/\n")
