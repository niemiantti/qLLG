#!/usr/bin/env python3
"""Numerical checks of the analytic statements of the draft (Secs. S1-S10 of the Supplemental
Material).  Each check prints PASS or FAIL; the script ends with a summary.  Runtime about two
minutes, dominated by the independent constrained minimizations (SLSQP over the unitary orbit)
that test the global optimality of the analytic minimizers.  Units hbar = omega = 1, eps = sqrt3.
"""
import os
import sys
import time

import numpy as np
from scipy.linalg import expm
from scipy.optimize import minimize_scalar

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from qllg.trimer import (EPS, H, J, J2, JP, CHI, SIG, SIGP, KET, BASIS, IDX, ENERGY, MVAL, C3, P23,
                         P_MINUS, P_QUAD, P_PLUS, comm, charge, expval, hs_norm, to_joint, from_joint,
                         gibbs_weights, gibbs_state, gibbs_energy, spectrum_vector, qmax_gibbs, hamiltonian)
from qllg.theory import (emin_gibbs, passive_value, dual_function, dual_function_analytic, charges_AB,
                         family_state, family_charge, two_spin_band, two_spin_amplitude,
                         rhodot_norm_prediction, exchange_state, emin_exchange, qcap_exchange,
                         emin_weak_exchange, constrained_minimum, PAIR_A, PAIR_B, PAIR_C)
from qllg.flow import covariant_velocity, velocities, pure_multiplier, haar_unitary, correct_charge, integrate

rng = np.random.default_rng(0)
RESULTS = []
T0 = time.time()


def check(name, ok, detail=""):
    RESULTS.append(bool(ok))
    print(f"[{'PASS' if ok else 'FAIL'}] {name}" + (f"   ({detail})" if detail else ""))


def levi(a, b, c):
    return {(0, 1, 2): 1, (1, 2, 0): 1, (2, 0, 1): 1, (1, 0, 2): -1, (2, 1, 0): -1, (0, 2, 1): -1}.get((a, b, c), 0)


def random_state(spectrum):
    U = haar_unitary(rng)
    return U @ np.diag(spectrum).astype(complex) @ U.conj().T


Z = np.array([0, 0, 1.0])
NJ = J[2]
BETA1 = 1.0 / EPS

# ====================================================================== S1 model and basis
print("--- S1  model, spectrum, joint eigenbasis")
check("spectrum of H is {-eps (2), 0 (4), +eps (2)}",
      np.allclose(np.linalg.eigvalsh(H), [-EPS] * 2 + [0] * 4 + [EPS] * 2, atol=1e-12))
check("[H, J_a] = 0 and [J_a, J_b] = i eps_abc J_c",
      max(np.abs(comm(H, Ja)).max() for Ja in J) < 1e-12 and all(
          np.allclose(comm(J[a], J[b]), 1j * sum(levi(a, b, c) * J[c] for c in range(3))) for a in range(3) for b in range(3)))
check("chirality = -+ 2 sqrt3 on the doublets, 0 on the quadruplet",
      np.allclose(np.linalg.eigvalsh(CHI), [-2 * EPS] * 2 + [0] * 4 + [2 * EPS] * 2))
check("H invariant under C3, odd under the transposition (23)",
      np.allclose(C3 @ H @ C3.conj().T, H) and np.allclose(P23 @ H @ P23, -H))
V = np.column_stack([KET[k] for k in BASIS])
check("joint basis (S3): orthonormal, H and J_z diagonal with the tabulated E and m",
      np.allclose(V.conj().T @ V, np.eye(8)) and np.allclose(to_joint(H), np.diag(ENERGY)) and np.allclose(to_joint(NJ), np.diag(MVAL)))
w3 = np.exp(2j * np.pi / 3)
up, dn = np.array([1, 0], complex), np.array([0, 1], complex)
kron3 = lambda a, b, c: np.kron(np.kron(a, b), c)
check("(S4): |3/2,3/2> = |uuu>, |-,-1/2> = (|ddu> + w3 |dud> + w3^2 |udd>)/sqrt3 with E = -eps",
      np.allclose(KET[("3/2", 1.5)], kron3(up, up, up)) and
      np.allclose(KET[("-", -0.5)], (kron3(dn, dn, up) + w3 * kron3(dn, up, dn) + w3 ** 2 * kron3(up, dn, dn)) / np.sqrt(3)) and
      abs(np.vdot(KET[("-", -0.5)], H @ KET[("-", -0.5)]) + EPS) < 1e-12)
check("Condon-Shortley ladders: J_+|mu,m> has a positive coefficient on |mu,m+1>",
      all(np.vdot(KET[(mu, m + 1)], JP @ KET[(mu, m)]).real > 0 and abs(np.vdot(KET[(mu, m + 1)], JP @ KET[(mu, m)]).imag) < 1e-12
          for (mu, m) in BASIS if (mu, m + 1) in KET))
c3eig = {k: np.vdot(KET[k], C3 @ KET[k]) for k in BASIS}
check("C3 eigenvalues: 1 on the quadruplet, w3 on |->, w3^-1 on |+>",
      all(abs(c3eig[k] - (1 if k[0] == "3/2" else (w3 if k[0] == "-" else w3.conj()))) < 1e-12 for k in BASIS))
check("Lemma 1: <mu,m|sigma_i|mu,m> = (2m/3) n on every site",
      all(np.allclose([np.vdot(KET[k], SIG[i][a] @ KET[k]) for a in range(3)], [0, 0, 2 * k[1] / 3], atol=1e-12)
          for k in BASIS for i in range(3)))

# ====================================================================== S2 Poisson brackets
print("--- S2  Poisson brackets, shifted constraints, direction of the multiplier")
W = haar_unitary(rng) @ np.diag(np.sqrt(spectrum_vector(BETA1)))
A = (lambda M: (M + M.conj().T) / 2)(rng.normal(size=(8, 8)) + 1j * rng.normal(size=(8, 8)))
B = (lambda M: (M + M.conj().T) / 2)(rng.normal(size=(8, 8)) + 1j * rng.normal(size=(8, 8)))
# canonical bracket {W_ia, W*_jb} = delta/(i hbar) applied to f = Tr(W^+ A W), g = Tr(W^+ B W)
pb = (np.sum((W.conj().T @ A).T * (B @ W)) - np.sum((W.conj().T @ B).T * (A @ W))) / 1j
check("(S6): canonical bracket of Uhlmann amplitudes gives {<A>,<B>} = <[A,B]>/(i hbar)",
      abs(pb - np.trace(W @ W.conj().T @ comm(A, B)) / 1j) < 1e-10)
rho = W @ W.conj().T
lp = lambda X, Y: np.trace(rho @ comm(X, Y)) / 1j
check("(S7)-(S8): {<J_a>,<J_b>} = eps_abc <J_c>, {<H>,<J_a>} = 0",
      all(abs(lp(J[a], J[b]) - sum(levi(a, b, c) * expval(rho, J[c]) for c in range(3))) < 1e-12 for a in range(3) for b in range(3))
      and all(abs(lp(H, Ja)) < 1e-12 for Ja in J))
R = expm(-1j * (0.7 * J[0] - 0.4 * J[1] + 1.1 * J[2]))
rr = R @ rho @ R.conj().T
check("(S9): a rotation keeps the spectrum and the energy and rotates the charge, |q| fixed",
      np.allclose(np.linalg.eigvalsh(rr), np.linalg.eigvalsh(rho)) and abs(expval(rr, H) - expval(rho, H)) < 1e-12
      and abs(np.linalg.norm(charge(rr)) - np.linalg.norm(charge(rho))) < 1e-12)

# ====================================================================== S3 Gibbs orbit
print("--- S3  the Gibbs orbit")
for be in (0.5, 1.0, 2.0, 4.0):
    beta = be / EPS
    pm, p0, pp = gibbs_weights(beta)
    Zc = 8 * np.cosh(beta * EPS / 2) ** 2
    ok = (abs(pm - np.exp(beta * EPS) / Zc) < 1e-14 and abs(p0 - 1 / Zc) < 1e-14 and abs(pp - np.exp(-beta * EPS) / Zc) < 1e-14
          and abs(gibbs_energy(beta) + EPS * np.tanh(beta * EPS / 2)) < 1e-14 and abs(pm - pp - 0.5 * np.tanh(beta * EPS / 2)) < 1e-14
          and abs(expval(gibbs_state(beta), H) - gibbs_energy(beta)) < 1e-14
          and np.allclose(gibbs_state(beta), expm(-beta * H) / np.trace(expm(-beta * H))))
    check(f"(S11)-(S12) at beta eps = {be}: weights, Z = 8 cosh^2, E_G = -eps tanh(beta eps/2), p_- - p_+", ok)

# ====================================================================== S4 trace inequality
print("--- S4  von Neumann's trace inequality")
ok = True
for _ in range(200):
    p = np.sort(rng.random(8))[::-1]; p /= p.sum()
    rho = random_state(p)
    K = (lambda M: (M + M.conj().T) / 2)(rng.normal(size=(8, 8)) + 1j * rng.normal(size=(8, 8)))
    kap = np.sort(np.linalg.eigvalsh(K))
    val = expval(rho, K)
    ok &= (p @ kap - 1e-12 <= val <= p @ kap[::-1] + 1e-12)
check("Theorem 1 (S14): sum p_k^down kappa_k^up <= Tr(rho K) <= sum p_k^down kappa_k^down, 200 random cases", ok)
K = (lambda M: (M + M.conj().T) / 2)(rng.normal(size=(8, 8)) + 1j * rng.normal(size=(8, 8)))
kap, Vk = np.linalg.eigh(K)
p = np.sort(rng.random(8))[::-1]; p /= p.sum()
rho_pass = Vk @ np.diag(p) @ Vk.conj().T
check("Lemma 2 / Corollary 1: equality for the passive state (eigenbasis of K, populations in opposite order)",
      abs(expval(rho_pass, K) - passive_value(p, K)) < 1e-12 and np.abs(comm(rho_pass, K)).max() < 1e-12)
for be in (0.5, 1.0, 2.0):
    beta = be / EPS
    P = spectrum_vector(beta)
    qm = -passive_value(P, -NJ)                    # max of Tr(rho n.J) on the orbit
    samples = max(expval(random_state(P), NJ) for _ in range(300))
    check(f"Corollary 2 (S17) at beta eps = {be}: max <n.J> on the orbit = tanh(beta eps/2) = {qmax_gibbs(beta):.6f}",
          abs(qm - qmax_gibbs(beta)) < 1e-12 and samples <= qm + 1e-12, f"300 random states stay below, largest {samples:.4f}")

# ====================================================================== S5 dual bound and crossing
print("--- S5  the Lagrange-multiplier bound and the level crossing")
for be in (0.5, 1.0, 2.0):
    beta = be / EPS
    lams = np.linspace(-3, 3, 241)
    Pnum = np.array([dual_function(l, beta) for l in lams])
    check(f"(S22) at beta eps = {be}: P(lambda) = P[H + lambda n.J] is E_G for |lambda| <= eps/2 and E_G + (eps/2 - |lambda|) q_max beyond",
          np.allclose(Pnum, dual_function_analytic(lams, beta), atol=1e-12))
lam = -EPS / 2
Kcr = H + lam * NJ
lev = {k: np.vdot(KET[k], Kcr @ KET[k]).real for k in BASIS}
check("(S21): at lambda = -eps/2 pair A sits at -3eps/4 and pair B at +3eps/4 (Delta m = 2, Delta E = eps)",
      abs(lev[PAIR_A[0]] + 0.75 * EPS) < 1e-12 and abs(lev[PAIR_A[1]] + 0.75 * EPS) < 1e-12
      and abs(lev[PAIR_B[0]] - 0.75 * EPS) < 1e-12 and abs(lev[PAIR_B[1]] - 0.75 * EPS) < 1e-12)
for be, q in ((1.0, 0.2), (2.0, 0.6), (0.5, 0.1)):
    beta = be / EPS
    sup = minimize_scalar(lambda l: -(dual_function_analytic(l, beta) - l * q), bounds=(-5, 5), method="bounded", options={"xatol": 1e-10})
    check(f"(S23) at beta eps = {be}, q = {q}: sup_lambda [P(lambda) - lambda q] = E_G + eps q/2 at lambda_cr = -eps/2",
          abs(-sup.fun - (gibbs_energy(beta) + EPS * q / 2)) < 1e-9 and abs(sup.x + EPS / 2) < 1e-5, f"lambda* = {sup.x:.6f}")

# ====================================================================== S6 minimizers
print("--- S6  the minimizers and the result")
beta = BETA1
pm, p0, pp = gibbs_weights(beta)
# (S24): passive state of K_cr: levels and populations
levels = np.array([lev[k] for k in BASIS])
pops = {k: {"-": pm, "3/2": p0, "+": pp}[k[0]] for k in BASIS}
rho_fam = family_state(beta, 0.3, 1.1, 0.4, -0.9)
check("(S24): the family is passive for K_cr: Tr(rho_* K_cr) = P(-eps/2) = E_G and [K_cr, rho_*] = 0",
      abs(expval(rho_fam, Kcr) - gibbs_energy(beta)) < 1e-12 and np.abs(comm(Kcr, rho_fam)).max() < 1e-12)
ok = True
for _ in range(50):
    th, vt, ph, vp = rng.random() * np.pi / 2, rng.random() * np.pi / 2, rng.random() * 2 * np.pi, rng.random() * 2 * np.pi
    r = family_state(beta, th, vt, ph, vp)
    q = family_charge(beta, th, vt)
    ok &= (np.allclose(np.sort(np.linalg.eigvalsh(r)), np.sort(spectrum_vector(beta)), atol=1e-12)
           and np.allclose(charge(r), [0, 0, q], atol=1e-12) and abs(expval(r, H) - (gibbs_energy(beta) + EPS * q / 2)) < 1e-12
           and np.abs(comm(Kcr, r)).max() < 1e-12)
check("(S25)-(S27): family members have the Gibbs spectrum, charge q n with q = q_A sin^2 th + q_B sin^2 vt, "
      "energy E_G + eps q/2, and commute with H - (eps/2) n.J (50 random members)", ok)
qA, qB = charges_AB(beta)
check("(S31): q_A = 2(p_- - p_0) = 0.3378, q_B = 2(p_0 - p_+) = 0.1243, q_A + q_B = q_max at beta eps = 1",
      abs(qA - 0.3378) < 5e-5 and abs(qB - 0.1243) < 5e-5 and abs(qA + qB - qmax_gibbs(beta)) < 1e-14, f"q_A = {qA:.6f}, q_B = {qB:.6f}")
# Theorem 2 against an independent constrained minimization on the orbit
for be, frac in ((1.0, 0.4), (2.0, 0.6), (0.5, 0.9)):
    beta_ = be / EPS
    q = frac * qmax_gibbs(beta_)
    t1 = time.time()
    best = constrained_minimum(spectrum_vector(beta_), q, restarts=5, seed=int(10 * be))
    check(f"Theorem 2 (S28) at beta eps = {be}, q = {q:.4f}: SLSQP minimum over the orbit = eps[q/2 - tanh(beta eps/2)]",
          best is not None and abs(best[0] - emin_gibbs(q, beta_)) < 2e-6,
          f"SLSQP {best[0] / EPS:+.7f} eps vs {emin_gibbs(q, beta_) / EPS:+.7f} eps, {time.time() - t1:.0f} s")
# Remark 1: Legendre duality (S29)
qs = np.linspace(0, qmax_gibbs(beta), 401)
ok = all(abs(min(emin_gibbs(qs, beta) - abs(l) * qs) - dual_function_analytic(l, beta)) < 1e-12 for l in np.linspace(-2, 2, 41))
ok &= all(abs(max(dual_function_analytic(np.linspace(-3, 3, 6001), beta) - np.linspace(-3, 3, 6001) * q) - emin_gibbs(q, beta)) < 1e-3 for q in qs[::40])
check("(S29): P and E_min are concave/convex conjugates on the Gibbs orbit", ok)
# uniqueness of the multiplier (S30)-(S31)
def gram(r):
    C = [comm(Ja, r) for Ja in J]
    return np.array([[np.real(np.trace(C[a].conj().T @ C[b])) for b in range(3)] for a in range(3)])
g_gen = np.linalg.eigvalsh(gram(family_state(beta, 0.5, 0.9)))
g_static = [np.linalg.eigvalsh(gram(family_state(beta, th, vt)))[0] for th in (0, np.pi / 2) for vt in (0, np.pi / 2)]
check("(S30)-(S31): [J_a, rho_*] independent for a generic member, dependent for the four diagonal members",
      g_gen[0] > 1e-6 and max(g_static) < 1e-12, f"smallest Gram eigenvalue {g_gen[0]:.2e} vs {max(g_static):.1e}")

# ====================================================================== S7 motion and signatures
print("--- S7  motion of the family and its signatures")
rho0 = family_state(beta, 0.5, 0.9, 0.3, -1.2)
evolve = lambda r, t: expm(-1j * H * t) @ r @ expm(1j * H * t)
rot = lambda r, t: expm(1j * lam * NJ * t) @ r @ expm(-1j * lam * NJ * t)
Tper = 2 * np.pi / EPS
check("(S32)-(S33): e^{-iHt} rho_* e^{iHt} = rotation about n with lambda_cr; period 2 pi hbar/eps, not pi hbar/eps",
      np.allclose(evolve(rho0, 0.37), rot(rho0, 0.37), atol=1e-12) and np.allclose(evolve(rho0, Tper), rho0, atol=1e-10)
      and hs_norm(evolve(rho0, Tper / 2) - rho0) > 1e-2)
ts = np.linspace(0, Tper, 7)
q0 = family_charge(beta, 0.5, 0.9)
check("(S34): <sigma_i> = (2q/3) n on every site at all times",
      all(np.allclose([expval(evolve(rho0, t), SIG[i][a]) for a in range(3)], [0, 0, 2 * q0 / 3], atol=1e-12) for t in ts for i in range(3)))
a_, A_, b_, B_ = KET[PAIR_A[0]], KET[PAIR_A[1]], KET[PAIR_B[0]], KET[PAIR_B[1]]
MA = {(i, j): np.vdot(A_, SIGP[i] @ SIGP[j] @ a_) for i in range(3) for j in range(3) if i != j}
MB = {(i, j): np.vdot(B_, SIGP[i] @ SIGP[j] @ b_) for i in range(3) for j in range(3) if i != j}
check("(S35): |M_A^{ij}| = |M_B^{ij}| = 1/sqrt3 and M_B = -M_A for all pairs of sites",
      all(abs(abs(MA[k]) - 1 / np.sqrt(3)) < 1e-12 and abs(MB[k] + MA[k]) < 1e-12 for k in MA))
th, vt, ph, vp = 0.5, 0.9, 0.3, -1.2
c12 = [np.trace(evolve(rho0, t) @ SIGP[0] @ SIGP[1]) for t in np.linspace(0, 1, 5)]
check("(S36): |<sigma_1^+ sigma_2^+>| = |sqrt(q_a(q_A-q_a)) + e^{i delta} sqrt(q_b(q_B-q_b))| / (2 sqrt3), rotating at eps/hbar",
      abs(abs(c12[0]) - two_spin_amplitude(beta, th, vt, ph, vp)) < 1e-12
      and all(abs(np.angle(c12[k] / c12[0]) - ((EPS * k / 4 + np.pi) % (2 * np.pi) - np.pi)) < 1e-10 for k in range(1, 5)))
lo, hi = two_spin_band(q0, beta)
check("(S36): the amplitude lies inside the band of admissible splits", lo - 1e-12 <= abs(c12[0]) <= hi + 1e-12,
      f"{abs(c12[0]):.4f} in [{lo:.4f}, {hi:.4f}]")
# the explicit example of Sec. S7 c
th, vt = 0.1751353550, 0.6010307390
qa, qb = qA * np.sin(th) ** 2, qB * np.sin(vt) ** 2
r = family_state(beta, th, vt, 0.0, 0.0)
cohA, cohB = (pm - p0) * np.sin(th) * np.cos(th), (p0 - pp) * np.sin(vt) * np.cos(vt)
two = max(abs(np.trace(r @ SIGP[i] @ SIGP[j])) for i in range(3) for j in range(3) if i != j)
three = [np.trace(evolve(r, t) @ SIGP[0] @ SIGP[1] @ SIG[2][2]) for t in np.linspace(0, Tper, 200)]
check("example (Sec. S7 c): th = 0.1751353550, vt = 0.6010307390 at beta eps = 1 give q = 0.05, q_a = 0.01025668677, "
      "q_b = 0.03974331323, equal coherences 0.02898217210, vanishing <sigma_i^+ sigma_j^+> and "
      "<sigma_1^+ sigma_2^+ sigma_3^z> oscillating with amplitude 0.03346572973",
      abs(qa + qb - 0.05) < 1e-9 and abs(qa - 0.01025668677) < 1e-9 and abs(qb - 0.03974331323) < 1e-9
      and abs(cohA - 0.02898217210) < 1e-9 and abs(cohB - 0.02898217210) < 1e-9 and two < 1e-10
      and abs(max(np.abs(three)) - 0.03346572973) < 1e-6, f"max two-spin {two:.1e}, three-spin amplitude {max(np.abs(three)):.11f}")
check("(S37): ||rho_dot_*||^2 = (eps^2/2)[q_a(q_A - q_a) + q_b(q_B - q_b)]",
      abs(hs_norm(-1j * comm(H, rho0)) - rhodot_norm_prediction(beta, 0.5, 0.9)) < 1e-12)

# ====================================================================== S8 limits
print("--- S8  limits and special cases")
D, lamG, infoG = covariant_velocity(gibbs_state(beta), 0.5)
rho_inv = pp * P_MINUS + p0 * P_QUAD + pm * P_PLUS
Dinv, _, _ = covariant_velocity(rho_inv, 0.5)
check("q = 0 (Remark 1): rho_G is a fixed point of the covariant flow, D_t rho = 0 for every lambda, and the charge-conservation "
      "system is M = c = 0 (to roundoff, so the multiplier is undetermined there); rho_inv (populations reversed) is another "
      "fixed point with energy -E_G",
      hs_norm(D) < 1e-12 and np.abs(infoG["M"]).max() < 1e-28 and np.abs(infoG["c"]).max() < 1e-28 and hs_norm(Dinv) < 1e-12
      and abs(expval(rho_inv, H) + gibbs_energy(beta)) < 1e-12 and np.linalg.norm(charge(rho_inv)) < 1e-12,
      f"||D|| = {hs_norm(D):.1e}, |M| = {np.abs(infoG['M']).max():.1e}, |c| = {np.abs(infoG['c']).max():.1e}")
r0 = family_state(np.inf, 0.6, 0.0, 0.4)
best = constrained_minimum([0.5, 0.5], np.sin(0.6) ** 2, restarts=4, seed=7)
check("(S38) T = 0: rank-two family with q = sin^2 theta and E = -eps + eps q/2; SLSQP minimum on the rank-two orbit agrees",
      abs(expval(r0, H) - emin_gibbs(np.sin(0.6) ** 2, np.inf)) < 1e-12 and np.allclose(charge(r0), [0, 0, np.sin(0.6) ** 2], atol=1e-12)
      and best is not None and abs(best[0] - emin_gibbs(np.sin(0.6) ** 2, np.inf)) < 2e-6, f"SLSQP {best[0] / EPS:+.7f} eps")
w = {("-", 0.5): .22, ("-", -0.5): .22, ("3/2", 1.5): .16, ("3/2", -1.5): .16, ("3/2", 0.5): .10, ("3/2", -0.5): .10, ("+", 0.5): .02, ("+", -0.5): .02}
r_other = sum(w[k] * np.outer(KET[k], KET[k].conj()) for k in BASIS)
Do, _, _ = covariant_velocity(r_other, 0.5)
check("other spectra, static example: diagonal state with weights 0.22/0.16/0.10/0.02 has q = 0, commutes with H and n.J, D_t rho = 0",
      np.linalg.norm(charge(r_other)) < 1e-12 and np.abs(comm(H, r_other)).max() < 1e-12 and np.abs(comm(NJ, r_other)).max() < 1e-12 and hs_norm(Do) < 1e-12)
psi = np.sqrt(0.75) * KET[("-", 0.5)] + np.sqrt(0.25) * KET[("3/2", -1.5)]
r_pure = np.outer(psi, psi.conj())
best = constrained_minimum([1.0], 0.0, restarts=6, seed=3)
lmin_sup = max(np.linalg.eigvalsh(H + l * NJ)[0] for l in np.linspace(-4, 4, 8001))
check("other spectra, moving example: pure state 3/4 |-,1/2> + 1/4 |3/2,-3/2> has q = 0 and E = -3eps/4, is the pure "
      "minimum at q = 0 (SLSQP), while sup_lambda lambda_min(H + lambda n.J) = -eps: a duality gap",
      np.linalg.norm(charge(r_pure)) < 1e-12 and abs(expval(r_pure, H) + 0.75 * EPS) < 1e-12 and best is not None
      and abs(best[0] + 0.75 * EPS) < 2e-6 and abs(lmin_sup + EPS) < 1e-6, f"SLSQP {best[0] / EPS:+.7f} eps, sup lambda_min = {lmin_sup / EPS:.6f} eps")

# ====================================================================== S9 exchange
print("--- S9  isotropic exchange and the doublet-mixing branch")
Jex = 0.8
Hex = Jex / 2 * (J2 - 2.25 * np.eye(8))
check("H_ex = (J/2)(J^2 - 9/4) equals -3J/4 on the doublets and +3J/4 on the quadruplet; H_Delta = H + Delta P_Q with Delta = 3J/2",
      np.allclose(Hex @ P_MINUS, -0.75 * Jex * P_MINUS) and np.allclose(Hex @ P_QUAD, 0.75 * Jex * P_QUAD)
      and np.allclose(H + Hex + 0.75 * Jex * np.eye(8), hamiltonian(1.5 * Jex)))
delta = 6 * EPS
pm_, p0_, pp_ = gibbs_weights(beta, delta)
Zd = 4 * np.cosh(beta * EPS) + 4 * np.exp(-beta * delta)
check("(S40): Gibbs weights and E_G of the exchange-shifted spectrum at Delta = 6 eps, beta eps = 1",
      abs(pm_ - np.exp(beta * EPS) / Zd) < 1e-14 and abs(p0_ - np.exp(-beta * delta) / Zd) < 1e-14 and abs(pp_ - np.exp(-beta * EPS) / Zd) < 1e-14
      and abs(gibbs_energy(beta, delta) - (delta * np.exp(-beta * delta) - EPS * np.sinh(beta * EPS)) / (np.cosh(beta * EPS) + np.exp(-beta * delta))) < 1e-13
      and abs(pm_ - pp_ - 0.3802) < 5e-5, f"p_- - p_+ = {pm_ - pp_:.6f}")
Hd = hamiltonian(delta)
E_ = lambda k: np.vdot(KET[k], Hd @ KET[k]).real
check("(S41): candidate crossings A, B, B', C have Delta E / Delta m = (eps+Delta)/2, (eps-Delta)/2, (Delta-eps)/2, 2 eps",
      abs((E_(("3/2", 1.5)) - E_(("-", -0.5))) / 2 - (EPS + delta) / 2) < 1e-12
      and abs((E_(("+", 0.5)) - E_(("3/2", -1.5))) / 2 - (EPS - delta) / 2) < 1e-12
      and abs((E_(("3/2", 1.5)) - E_(("+", -0.5))) / 2 - (delta - EPS) / 2) < 1e-12
      and abs((E_(("+", 0.5)) - E_(("-", -0.5))) - 2 * EPS) < 1e-12)
lams = np.linspace(-12, 12, 24001)
Pd = np.array([passive_value(spectrum_vector(beta, delta), Hd + l * NJ) for l in lams[::20]])
cap = qcap_exchange(beta, delta)
ok = True
for q in np.linspace(0, cap, 9)[:-1]:
    legendre = max(np.array([passive_value(spectrum_vector(beta, delta), Hd + l * NJ) for l in lams]) - lams * q)
    ok &= abs(legendre - emin_exchange(q, beta, delta)) < 2e-3
check("(S44): E_min(q) on the exchange-shifted orbit (four segments, cap 2c + 3d) equals the Legendre transform of P_Delta(lambda)", ok)
ok = True
for chi in (0.4, 1.0):
    r = exchange_state(beta, delta, chi, 0.7)
    q = (pm_ - pp_) * np.sin(chi) ** 2
    ok &= (np.allclose(np.sort(np.linalg.eigvalsh(r)), np.sort(spectrum_vector(beta, delta)), atol=1e-12)
           and np.allclose(charge(r), [0, 0, q], atol=1e-12) and abs(expval(r, Hd) - (gibbs_energy(beta, delta) + 2 * EPS * q)) < 1e-12
           and np.abs(comm(Hd - 2 * EPS * NJ, r)).max() < 1e-12)
check("(S42)-(S43): the doublet-mixing states have the shifted Gibbs spectrum, q = (p_- - p_+) sin^2 chi, "
      "E = E_G + 2 eps q and commute with H_Delta - 2 eps n.J", ok)
q = 0.2
t1 = time.time()
best = constrained_minimum(spectrum_vector(beta, delta), q, delta=delta, restarts=4, seed=11)
check("(S43) at Delta = 6 eps, q = 0.2: SLSQP minimum over the orbit = E_G + 2 eps q", best is not None and abs(best[0] - emin_exchange(q, beta, delta)) < 2e-6,
      f"SLSQP {best[0] / EPS:+.7f} eps vs {emin_exchange(q, beta, delta) / EPS:+.7f} eps, {time.time() - t1:.0f} s")
r = exchange_state(beta, delta, 0.8, 0.3)
q = (pm_ - pp_) * np.sin(0.8) ** 2
ev_d = lambda r, t: expm(-1j * Hd * t) @ r @ expm(1j * Hd * t)
coh = [to_joint(ev_d(r, t))[IDX[PAIR_C[0]], IDX[PAIR_C[1]]] for t in (0, 0.25, 0.5)]
sp = [np.trace(r @ SIGP[i]) for i in range(3)]
steps = [(np.angle(sp[(i + 1) % 3]) - np.angle(sp[i]) + np.pi) % (2 * np.pi) - np.pi for i in range(3)]
check("(S45)-(S46): coherence sqrt(q(p_- - p_+ - q)) rotating at 2 eps/hbar; |<sigma_i^+>| = (2/3) sqrt(q(p_- - p_+ - q)) on every site, "
      "phases 2 pi/3 apart, zero transverse sum, <sigma_i^z> = 2q/3, no double-raising correlations, period pi hbar/eps",
      abs(abs(coh[0]) - np.sqrt(q * (pm_ - pp_ - q))) < 1e-12 and abs(np.angle(coh[1] / coh[0]) - 2 * EPS * 0.25) < 1e-10
      and all(abs(abs(s) - 2 / 3 * np.sqrt(q * (pm_ - pp_ - q))) < 1e-12 for s in sp) and all(abs(abs(st) - 2 * np.pi / 3) < 1e-10 for st in steps)
      and abs(sum(sp)) < 1e-12 and all(abs(expval(r, SIG[i][2]) - 2 * q / 3) < 1e-12 for i in range(3))
      and max(abs(np.trace(r @ SIGP[i] @ SIGP[j])) for i in range(3) for j in range(3) if i != j) < 1e-12
      and np.allclose(ev_d(r, np.pi / EPS), r, atol=1e-10))
dw = 0.5 * EPS
ok = True
for q in np.linspace(0, 2 * (gibbs_weights(beta, dw)[0] - gibbs_weights(beta, dw)[2]), 7)[:-1]:
    legendre = max(np.array([passive_value(spectrum_vector(beta, dw), hamiltonian(dw) + l * NJ) for l in lams]) - lams * q)
    ok &= abs(legendre - emin_weak_exchange(q, beta, dw)) < 2e-3
check("(S47): weak exchange Delta = eps/2: the two-segment E_min(q) with the kink at q_B equals the Legendre transform of P_Delta", ok)

# ====================================================================== S10 the flow
print("--- S10  the covariant velocity, the multipliers and the amplitude equation")
kappa = 0.5
rho = random_state(spectrum_vector(beta))
D, lam3, info = covariant_velocity(rho, kappa)
X = H + sum(l * Ja for l, Ja in zip(lam3, J))
check("(S48) solves Eq. (11): i D = [H + lambda.J + kappa D, rho]; D Hermitian, traceless, orthogonal to the spectrum",
      np.abs(1j * D - comm(X + kappa * D, rho)).max() < 1e-12 and np.allclose(D, D.conj().T) and abs(np.trace(D)) < 1e-12
      and abs(np.trace(D @ rho)) < 1e-12)
Dh, rd, _ = velocities(rho, kappa)
check("Eq. (12): with the multipliers from the 3x3 system the charges are conserved, d<J_a>/dt = Tr(J_a rho_dot) = 0, residual ||M lambda + c|| ~ 1e-16",
      max(abs(expval(rd, Ja)) for Ja in J) < 1e-12 and info["residual"] < 1e-13, f"residual {info['residual']:.1e}")
check("Eq. (13): d<H>/dt = Tr(H rho_dot) = -kappa Tr(D^2) < 0", abs(expval(rd, H) + kappa * np.real(np.trace(D @ D))) < 1e-12 and expval(rd, H) < 0)
c = rng.normal(size=3)
p, Vr = np.linalg.eigh(rho)
Qk = Vr.conj().T @ sum(ci * Ja for ci, Ja in zip(c, J)) @ Vr
dkl = p[None, :] - p[:, None]
s49 = -np.sum(dkl ** 2 / (1 + kappa ** 2 * dkl ** 2) * np.abs(Qk) ** 2)
check("(S49): c^a M_ab c^b = -(1/hbar) sum_kl d_kl^2 |Q_kl|^2 / (1 + kappa^2 d_kl^2) < 0 (M negative definite for independent commutators)",
      abs(c @ info["M"] @ c - s49) < 1e-12 and np.all(np.linalg.eigvalsh((info["M"] + info["M"].T) / 2) < 0))
psi = rng.normal(size=8) + 1j * rng.normal(size=8); psi /= np.linalg.norm(psi)
rp = np.outer(psi, psi.conj())
# one charge Q = J_z: solve d<Q>/dt = i kappa Tr(D(lambda)[Q, rho]) = 0 directly from the affine D
D0, _, _ = covariant_velocity(rp, kappa, lam=[0, 0, 0.0]); D1, _, _ = covariant_velocity(rp, kappa, lam=[0, 0, 1.0])
f0 = np.real(1j * np.trace(D0 @ comm(NJ, rp))); f1 = np.real(1j * np.trace(D1 @ comm(NJ, rp)))
lam1 = -f0 / (f1 - f0)
check("Eq. (15): for a pure state and one charge, charge conservation gives lambda = -(<HQ> - <H><Q>)/(<Q^2> - <Q>^2)",
      abs(lam1 - pure_multiplier(psi, NJ)) < 1e-10, f"{lam1:.8f} vs {pure_multiplier(psi, NJ):.8f}")
psi2 = 0.6 * KET[("-", -0.5)] + 0.8 * np.exp(0.4j) * KET[("3/2", 1.5)]
check("Eq. (15) at a two-level superposition: lambda = -(E_2 - E_1)/(q_2 - q_1) = -eps/2 for any amplitudes",
      abs(pure_multiplier(psi2, NJ) + EPS / 2) < 1e-12)
# interaction picture: the Schroedinger-picture amplitude equation gives the same trajectory
W0 = haar_unitary(rng) @ np.diag(np.sqrt(spectrum_vector(beta)))
W0, _, _ = correct_charge(W0, 0.2)
run = integrate(W0, kappa=kappa, t_end=6.0, n_out=13)
from scipy.integrate import solve_ivp
def rhs_s(t, y):
    Wm = y.reshape(8, 8)
    Dm, _, _ = covariant_velocity(Wm @ Wm.conj().T, kappa)
    return (-1j * (H + kappa * Dm) @ Wm).reshape(-1)
sol = solve_ivp(rhs_s, (0, 6.0), W0.reshape(-1).astype(complex), method="DOP853", rtol=1e-11, atol=1e-13, t_eval=[6.0])
Ws = sol.y[:, -1].reshape(8, 8)
check("interaction picture: integrating i W_dot = (H + kappa D) W and i W_I_dot = kappa D[rho_I] W_I with W = e^{-iHt} W_I agree",
      hs_norm(Ws - run["W"][-1]) < 1e-8 and run["spec_dev"].max() < 1e-10 and np.abs(run["q"] - run["q"][0]).max() < 1e-10
      and np.all(np.diff(run["E"]) < 0), f"difference {hs_norm(Ws - run['W'][-1]):.1e}, spectrum drift {run['spec_dev'].max():.1e}")
# relative equilibria are fixed points of the covariant flow with the predicted multipliers
for name, r, lam_pred in (("Gibbs-orbit member", family_state(beta, 0.5, 0.9, 0.3, -1.2), -EPS / 2),
                          ("exchange-branch member", exchange_state(beta, delta, 0.8, 0.3), -2 * EPS)):
    Hd_ = H if lam_pred == -EPS / 2 else hamiltonian(delta)
    Df, rdf, lamf = velocities(r, kappa, Hd_)
    check(f"{name}: D_t rho = 0, lambda = {lam_pred / EPS:+.1f} eps n from the 3x3 system, rho_dot = -i[H, rho] != 0",
          hs_norm(Df) < 1e-10 and np.allclose(lamf, [0, 0, lam_pred], atol=1e-8) and hs_norm(rdf) > 1e-2, f"||rho_dot|| = {hs_norm(rdf):.4f}")

print(f"\n{sum(RESULTS)}/{len(RESULTS)} checks passed in {time.time() - T0:.0f} s")
sys.exit(0 if all(RESULTS) else 1)
