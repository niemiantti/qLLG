# qLLG — covariant quantum Landau–Lifshitz–Gilbert relaxation of a chiral spin trimer

Simulation codes, data and figure for the draft by Antti Niemi entitled
**"Quantum Hamiltonian time crystals from covariant quantum Landau–Lifshitz–Gilbert relaxation"**.
Equation and section numbers below refer to that draft and to its Supplemental Material (Secs. S1–S10).

The package integrates the symmetry-covariant quantum Landau–Lifshitz–Gilbert (qLLG) flow for
three spins-½ coupled through their scalar chirality, with the Lagrange multipliers of the
conserved total spin fixed dynamically by charge conservation, and verifies numerically that the
flow converges onto the constrained energy minima derived in the draft: the moving minima
(quantum time crystals) and the static end points. It reproduces Tables S1–S3 and Fig. 1 of the
draft, and it checks every analytic statement of Secs. S1–S10 against independent numerics.

This repository replaces the earlier `qllg-triad` package (pure and rank-two spectra at zero
charge). Everything here is new: Gibbs orbits at finite temperature, prescribed charge, the
exchange-shifted orbit, the complete diagnostics of the tables, and the verification suite.

## Model and equations

Units ħ = ω = 1, so that ε = √3; damping κ = 0.5 throughout; the charge direction is n = ẑ.

* Hamiltonian and charges, Eq. (17):
  `H = ½ σ₁·(σ₂×σ₃)`, `J_a = ½ Σᵢ σᵢᵃ`, `[H, J_a] = 0`.
  Spectrum −ε (doublet |−⟩), 0 (quadruplet), +ε (doublet |+⟩). The joint eigenbasis |μ, m⟩ of
  H and J_z follows Eqs. (S3)–(S4): |3/2, 3/2⟩ = |↑↑↑⟩, |−, −½⟩ = (|↓↓↑⟩ + ω₃|↓↑↓⟩ + ω₃²|↑↓↓⟩)/√3,
  Condon–Shortley ladders, and these conventions fix the phases of all observables.
* Optional isotropic exchange, Sec. S9: `H_Δ = H + Δ P_Q`, energies measured from the centre of
  the doublets (Δ = 6ε in the draft).
* Covariant qLLG flow, Eqs. (10)–(11):
  `i ρ̇ = [H + κ 𝒟ₜρ, ρ]`, `i 𝒟ₜρ = [H + λ·J + κ 𝒟ₜρ, ρ]`.
  In the eigenbasis ρ = Σ pₖ|k⟩⟨k| the second equation is algebraic, Eq. (S48),
  `(𝒟ₜρ)ₖₗ = (H + λ·J)ₖₗ (pₗ − pₖ) / [i − κ(pₗ − pₖ)]`, and affine in λ.
* Multipliers, Eq. (12): `d⟨J_a⟩/dt = iκ Tr(𝒟ₜρ [J_a, ρ]) = 0` is a real 3×3 linear system
  `M λ = −c`, solved at every stage by minimum-norm least squares (singular values below
  3 ε_mach times the largest are discarded); the residual ‖Mλ + c‖ is monitored.
* Amplitudes, Eq. (16): Uhlmann amplitudes W (8×8, or 8×2 at T = 0) with ρ = WW†, W†W = P the
  prescribed spectrum, gauge 𝒜 = 0 and ν = 0: `i Ẇ = (H + κ 𝒟ₜρ) W`. The Hermitian generator
  conserves the spectrum. Because [H, J_a] = 0 the substitution W = e^{−iHt} W_I removes the
  Hamiltonian rotation exactly; the code integrates `i Ẇ_I = κ 𝒟ₜρ[ρ_I] W_I` with the same
  multipliers and evaluates all observables in the Schrödinger picture (Sec. S10 c).
* Integration: adaptive eighth-order Runge–Kutta (`scipy` DOP853), relative tolerance 10⁻¹⁰,
  absolute tolerance 10⁻¹², up to T_end = 600/ω (3000/ω at βε = 4), output every 0.5/ω.
* Initial states (Sec. S10 d): a Haar-random 8×8 unitary U (generator seeded with 20261028, one
  unitary per table row in the order of the rows) applied to the diagonal amplitudes,
  W(0) = U P^{1/2} (first two columns at T = 0), followed by a damped Newton correction along
  the orbit with the spectrum-preserving generators i[ρ, J_a] until |⟨J⟩ − q n| < 10⁻¹³. No
  information about the minimizers enters.

## Contents

| path | purpose |
|---|---|
| `qllg/trimer.py` | operators, joint eigenbasis (S3)–(S4), C₃, Gibbs weights (S11), exchange shift (S39)–(S40) |
| `qllg/flow.py` | covariant velocity (S48), 3×3 multiplier system, Haar initial states and charge correction, interaction-picture integrator, decay-rate fit |
| `qllg/theory.py` | E_min(q) (S28), dual function P(λ) (S22), the minimizing family (S25)–(S27), two-spin band (S36), ‖ρ̇‖ (S37), exchange branch (S42)–(S47), independent constrained minimization (SLSQP) |
| `qllg/diagnostics.py` | the columns of Tables S1–S3: family fit r_fam, forbidden coherences, δ₂₃, rates, moments, observables after relaxation |
| `run_tables.py` | runs every row of Tables S1–S3 and writes `data/` and `tables/` |
| `make_fig1.py` | Fig. 1(a)–(c) from `data/` |
| `verify_analytics.py` | 64 PASS/FAIL checks of the analytic statements of Secs. S1–S10 |
| `tables_format.py` | CSV / Markdown / LaTeX output of the tables |
| `tests/test_quick.py` | fast `pytest` suite (conventions, flow identities, a short integration) |
| `data/` | results of `run_tables.py`: `table_S?.npz` (initial and final amplitudes, scalar diagnostics along every run, W_I(t) every 5/ω) and `table_S?.json` (all table entries) |
| `tables/` | `table_S?.md`, `.csv` (every diagnostic), `.tex` (rows in the layout of the draft) |
| `figures/` | `fig1.pdf`, `fig1.png` |

## Usage

```bash
pip install -r requirements.txt
python verify_analytics.py      # ~3 min: PASS/FAIL for each analytic statement of Secs. S1–S10
python run_tables.py            # ~2.5 min: 43 runs -> data/ and tables/   (or: run_tables.py S1 S3)
python make_fig1.py             # ~5 s: figures/fig1.pdf, fig1.png
python -m pytest tests -q       # ~20 s
```

`run_all.sh` executes the three steps in order. Runtimes are for one core of a laptop.

### What the runs show

* **Table S1** (Gibbs orbits, βε = ½, 1, 2, 4 and T = 0; q/q_max = 0, 0.2, 0.4, 0.6, 0.8, 0.97):
  every run with q > 0 ends on the family (S25)–(S26): the fit residual r_fam is below 10⁻⁶,
  the forbidden coherences below 10⁻⁶, the energy agrees with E_min(q) = ε[q/2 − tanh(βε/2)] to
  4×10⁻¹² ε, the multiplier is −(ε/2) n to 10⁻¹¹ in magnitude and 10⁻⁶ in direction, the angles
  read off the populations satisfy the constraint (S27), and the two-spin amplitude lies inside
  the band (S36). The covariant velocity decays exponentially at 0.020–0.023 ω (βε = ½),
  0.027–0.029 ω (βε = 1), 0.020 ω (βε = 2), 0.0038 ω (βε = 4) and 0.20 ω (T = 0). The runs at
  q = 0 approach the Gibbs state itself.
* **Table S2** (βε = 1; q = 0, 0.2, 0.4 twice each, and the isolated charges q_A, q_B of (S31)):
  runs with the same q end at different members of the family (different sin²θ, sin²ϑ and
  amplitudes, same frequency), the physical velocity ‖ρ̇‖ agrees with Eq. (S37) to 10⁻¹², and the
  runs at q_A and q_B end at moving members. These six runs at q = 0, 0.2, 0.4 are Fig. 1(b).
* **Table S3** (exchange-shifted orbit, Δ = 6ε, βε = 1; q = 0, 0.1, 0.2, 0.2, 0.3): every run with
  q > 0 ends on the doublet-mixing branch (S42) with E = E_G + 2εq, λ_cr = −2ε n,
  sin²χ = q/(p₋ − p₊), the coherence (S45), local moments of transverse length
  (4/3)√(q(p₋ − p₊ − q)) with 2π/3 phase lags and zero transverse sum, no double-raising
  correlations, and decay rate 0.051 ω.
* Along every run the spectrum (hence the entropy) and ⟨J⟩ are constant to 4×10⁻¹¹ and
  2×10⁻¹¹, the energy decreases monotonically, the residual of the 3×3 system stays below
  5×10⁻¹⁵, and ‖λ·[J, ρ]‖ stays below 0.4 ε on the Gibbs orbits (1.6 ε on the exchange-shifted
  orbit, where the multiplier passes through 2.5 ε before settling at 2 ε). All of this is stored in `data/table_S?.npz` and summarized in `tables/table_S?.csv`.

### Notes on the tables

* The decay rate is the least-squares slope of −ln‖𝒟ₜρ‖ against t over 10⁻⁸ ≤ ‖𝒟ₜρ‖ ≤ 10⁻⁶
  (the last two decades above the final value when a run ends higher, as at βε = 4). The runs
  at q = 0 decay in two stages (about 0.05 ω first at βε = 1, then the rate of the q > 0 runs);
  their tabulated rate is marked † and depends on where the crossover falls. The CSV files also
  list the early-stage rate and the fit window.
* The final value of ‖𝒟ₜρ‖ at q = 0 is a floor set by the integration tolerance: near the
  SU(2)-invariant Gibbs state the matrix M of the multiplier system is quadratic in the distance
  ‖ρ − ρ_G‖, so the multiplier is determined less and less precisely as the run approaches ρ_G,
  and the floor rises with the inverse of that distance. The multiplier observed on such a run
  (|λ| = ε/2 in a direction set by the initial state) is a property of the path, not of the end
  point (Remark 1 of the draft).
* The quantities that depend on the random initial state — the angles (sin²θ, sin²ϑ), the
  amplitudes, the direction of λ at q = 0 and the final floors — differ between implementations
  of the random stream even for the same seed. The predicted quantities (energies, multipliers,
  bands, moments, periods, rates of the q > 0 runs) do not. The tables in `tables/` are those
  produced by this code; `tables/table_S?.tex` gives the rows in the layout of the draft.

## Verification suite

`verify_analytics.py` checks, among other things: the joint eigenbasis and Lemma 1; the
Lie–Poisson bracket of the Uhlmann amplitudes (S6)–(S8); von Neumann's trace inequality
(Theorem 1) on random states and its equality case; the orbit bound q_max = tanh(βε/2)
(Corollary 2); the dual function (S22) and the selection λ_cr = −ε/2 (S23); the family
(S25)–(S27), the constraint and the commutation with H − (ε/2) n·J; Theorem 2 against an
independent SLSQP minimization over the unitary orbit; the Legendre duality (S29); the
uniqueness criterion (S30)–(S31); the rotation and period (S32)–(S33); the static single-spin
moments (S34), the two-spin amplitude and band (S35)–(S36) including the explicit cancelling
example of Sec. S7 c; the velocity formula (S37); the limits of Sec. S8 (Gibbs state, ρ_inv,
T = 0, the static and the moving examples with other spectra and the duality gap); the exchange
sector (S39)–(S47) including E_min on the exchange-shifted orbit against the Legendre transform
of P_Δ and against SLSQP; and the flow itself: (S48) solves Eq. (11), the charges are conserved,
the energy decreases as −κ Tr(𝒟ₜρ)² (Eq. 13), the identity (S49), the pure-state multiplier
(15), the exactness of the interaction picture, and the relative equilibria as fixed points of
the covariant flow with the predicted multipliers.

## Data files

`data/table_S?.npz` (plain NumPy archives; `qllg.data.load_table("S1")` returns the runs as a list
of dicts) contain, per run k, the arrays `rkk_W0` and `rkk_W_end` (initial and final amplitudes in the Schrödinger picture, 8×8; the T = 0 runs
are zero-padded from 8×2), `rkk_WI_end`, the time grid `rkk_t` and the series `rkk_E`, `rkk_q`
(charge vector), `rkk_lam` (multipliers), `rkk_normD`, `rkk_normRhoDot`, `rkk_spec_dev`,
`rkk_residual`, `rkk_normLamJ`, and the coarse trajectory `rkk_WI_coarse` with `rkk_t_coarse`
(every 5/ω). `data/table_S?.json` holds every entry of the
tables plus the fitted angles. Fig. 1(c) propagates `W_end` of the first q = 0.2 run of Table S2
(top) and of Table S3 (bottom) with the von Neumann equation.

## Requirements

Python ≥ 3.9 with `numpy`, `scipy` and `matplotlib` (see `requirements.txt`). No other
dependencies.

## Licence and credit

MIT licence, see `LICENSE`. The code was written with the assistance of large language models
under the author's direction. Please cite the draft named above when using this code.
