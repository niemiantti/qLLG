#!/bin/sh
# Reproduce everything: analytic checks, the 43 runs of Tables S1-S3, and Fig. 1.
set -e
cd "$(dirname "$0")"
python verify_analytics.py
python run_tables.py
python make_fig1.py
