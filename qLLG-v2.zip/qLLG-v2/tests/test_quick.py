"""Fast checks (pytest): conventions of the trimer, the flow identities, and a short integration.
Run with  python -m pytest tests -q  from the repository root (about 20 s)."""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from qllg.trimer import (EPS, H, J, KET, BASIS, SIG, SIGP, comm, charge, expval, hs_norm, to_joint,
                         gibbs_weights, gibbs_state, gibbs_energy, spectrum_vector, qmax_gibbs, hamiltonian)
from qllg.theory import (emin_gibbs, family_state, family_charge, read_angles, fit_family, two_spin_band,
                         rhodot_norm_prediction, exchange_state, emin_exchange, fit_exchange_branch, charges_AB)
from qllg.flow import (covariant_velocity, velocities, haar_unitary, correct_charge, initial_amplitude,
                       integrate, decay_rate, pure_multiplier)

rng = np.random.default_rng(1)
BETA = 1.0 / EPS


def test_spectrum_and_symmetry():
    assert np.allclose(np.linalg.eigvalsh(H), [-EPS] * 2 + [0] * 4 + [EPS] * 2)
    assert max(np.abs(comm(H, Ja)).max() for Ja in J) < 1e-12


def test_joint_basis_conventions():
    a, A = KET[("-", -0.5)], KET[("3/2", 1.5)]
    assert abs(np.vdot(a, H @ a) + EPS) < 1e-12 and abs(np.vdot(A, J[2] @ A) - 1.5) < 1e-12
    MA = np.vdot(A, SIGP[0] @ SIGP[1] @ a)
    MB = np.vdot(KET[("+", 0.5)], SIGP[0] @ SIGP[1] @ KET[("3/2", -1.5)])
    assert abs(abs(MA) - 1 / np.sqrt(3)) < 1e-12 and abs(MB + MA) < 1e-12
    for k in BASIS:
        for i in range(3):
            assert np.allclose([np.vdot(KET[k], SIG[i][c] @ KET[k]) for c in range(3)], [0, 0, 2 * k[1] / 3], atol=1e-12)


def test_gibbs_orbit_numbers():
    pm, p0, pp = gibbs_weights(BETA)
    assert abs(gibbs_energy(BETA) + EPS * np.tanh(0.5)) < 1e-14
    assert abs(qmax_gibbs(BETA) - 2 * (pm - pp)) < 1e-14
    qA, qB = charges_AB(BETA)
    assert abs(qA - 0.3378) < 5e-5 and abs(qB - 0.1243) < 5e-5


def test_family_is_relative_equilibrium():
    th, vt, ph, vp = 0.4, 1.0, 0.2, -0.7
    r = family_state(BETA, th, vt, ph, vp)
    q = family_charge(BETA, th, vt)
    assert np.allclose(np.sort(np.linalg.eigvalsh(r)), np.sort(spectrum_vector(BETA)), atol=1e-12)
    assert np.allclose(charge(r), [0, 0, q], atol=1e-12)
    assert abs(expval(r, H) - emin_gibbs(q, BETA)) < 1e-12
    assert np.abs(comm(H - EPS / 2 * J[2], r)).max() < 1e-12
    D, rd, lam = velocities(r, 0.5)
    assert hs_norm(D) < 1e-10 and np.allclose(lam, [0, 0, -EPS / 2], atol=1e-8)
    assert abs(hs_norm(rd) - rhodot_norm_prediction(BETA, th, vt)) < 1e-10
    s2t, s2v, d23 = read_angles(r, BETA)
    assert abs(s2t - np.sin(th) ** 2) < 1e-12 and abs(s2v - np.sin(vt) ** 2) < 1e-12 and abs(d23) < 1e-12
    rfam, ang = fit_family(r, BETA)
    assert rfam < 1e-9
    lo, hi = two_spin_band(q, BETA)
    assert lo - 1e-12 <= abs(np.trace(r @ SIGP[0] @ SIGP[1])) <= hi + 1e-12


def test_exchange_branch():
    delta = 6 * EPS
    pm, p0, pp = gibbs_weights(BETA, delta)
    r = exchange_state(BETA, delta, 0.7, 0.3)
    q = (pm - pp) * np.sin(0.7) ** 2
    assert abs(expval(r, hamiltonian(delta)) - emin_exchange(q, BETA, delta)) < 1e-12
    D, rd, lam = velocities(r, 0.5, hamiltonian(delta))
    assert hs_norm(D) < 1e-10 and np.allclose(lam, [0, 0, -2 * EPS], atol=1e-8)
    sp = [np.trace(r @ SIGP[i]) for i in range(3)]
    assert all(abs(abs(s) - 2 / 3 * np.sqrt(q * (pm - pp - q))) < 1e-12 for s in sp) and abs(sum(sp)) < 1e-12
    assert fit_exchange_branch(r, BETA, delta)[0] < 1e-9


def test_covariant_velocity_identities():
    U = haar_unitary(rng)
    rho = U @ np.diag(spectrum_vector(BETA)).astype(complex) @ U.conj().T
    kappa = 0.5
    D, lam, info = covariant_velocity(rho, kappa)
    X = H + sum(l * Ja for l, Ja in zip(lam, J))
    assert np.abs(1j * D - comm(X + kappa * D, rho)).max() < 1e-12
    rd = -1j * comm(H + kappa * D, rho)
    assert max(abs(expval(rd, Ja)) for Ja in J) < 1e-12
    assert abs(expval(rd, H) + kappa * np.real(np.trace(D @ D))) < 1e-12 and expval(rd, H) < 0
    assert info["residual"] < 1e-13


def test_pure_multiplier():
    psi = 0.6 * KET[("-", -0.5)] + 0.8 * np.exp(0.3j) * KET[("3/2", 1.5)]
    assert abs(pure_multiplier(psi, J[2]) + EPS / 2) < 1e-12


def test_initial_state_and_short_integration():
    W0, err = initial_amplitude(rng, spectrum_vector(BETA), 0.3)
    assert err < 1e-13
    assert np.allclose(W0.conj().T @ W0, np.diag(spectrum_vector(BETA)), atol=1e-12)
    run = integrate(W0, kappa=0.5, t_end=20.0, n_out=41)
    assert run["spec_dev"].max() < 1e-10
    assert np.abs(np.linalg.norm(run["q"], axis=1) - 0.3).max() < 1e-10
    assert np.all(np.diff(run["E"]) < 0)
    assert run["residual"].max() < 1e-13


def test_rank_two_initial_state():
    W0, err = initial_amplitude(rng, np.array([0.5, 0.5]), 0.4)
    assert W0.shape == (8, 2) and err < 1e-13
    run = integrate(W0, kappa=0.5, t_end=5.0, n_out=11)
    assert run["spec_dev"].max() < 1e-10 and np.all(np.diff(run["E"]) < 0)


def test_decay_rate_fit():
    t = np.linspace(0, 600, 1201)
    nD = np.exp(-0.027 * t) + 1e-10
    rate, window = decay_rate(t, nD, window=(1e-8, 1e-6))
    assert abs(rate - 0.027) < 1e-3
